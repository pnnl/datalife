/bin/curl -L -o poss2ukstu_blue_001_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.679435&d=23.095942&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_001_001.fits pposs2ukstu_blue_001_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_001_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.683228&d=23.595801&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_001_002.fits pposs2ukstu_blue_001_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_001_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.687050&d=24.095720&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_001_003.fits pposs2ukstu_blue_001_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_001_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.690902&d=24.595624&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_001_004.fits pposs2ukstu_blue_001_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_001_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.694784&d=25.095437&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_001_005.fits pposs2ukstu_blue_001_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_001_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.698697&d=25.595083&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_001_006.fits pposs2ukstu_blue_001_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_002_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.136009&d=23.098364&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_002_001.fits pposs2ukstu_blue_002_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_002_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.137698&d=23.598282&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_002_002.fits pposs2ukstu_blue_002_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_002_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.139400&d=24.098261&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_002_003.fits pposs2ukstu_blue_002_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_002_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.141115&d=24.598224&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_002_004.fits pposs2ukstu_blue_002_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_002_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.142844&d=25.098097&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_002_005.fits pposs2ukstu_blue_002_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_002_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=57.144586&d=25.597802&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_002_006.fits pposs2ukstu_blue_002_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_003_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.592505&d=23.098927&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_003_001.fits pposs2ukstu_blue_003_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_003_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.592089&d=23.598858&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_003_002.fits pposs2ukstu_blue_003_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_003_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.591670&d=24.098851&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_003_003.fits pposs2ukstu_blue_003_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_003_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.591247&d=24.598828&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_003_004.fits pposs2ukstu_blue_003_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_003_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.590820&d=25.098714&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_003_005.fits pposs2ukstu_blue_003_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_003_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.590391&d=25.598433&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_003_006.fits pposs2ukstu_blue_003_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_004_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.049021&d=23.097629&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_004_001.fits pposs2ukstu_blue_004_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_004_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.046500&d=23.597528&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_004_002.fits pposs2ukstu_blue_004_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_004_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.043959&d=24.097489&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_004_003.fits pposs2ukstu_blue_004_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_004_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.041398&d=24.597434&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_004_004.fits pposs2ukstu_blue_004_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_004_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.038818&d=25.097289&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_004_005.fits pposs2ukstu_blue_004_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_004_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=56.036217&d=25.596976&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_004_006.fits pposs2ukstu_blue_004_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_005_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=55.505654&d=23.094471&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_005_001.fits pposs2ukstu_blue_005_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_005_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=55.501029&d=23.594293&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_005_002.fits pposs2ukstu_blue_005_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_005_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=55.496368&d=24.094177&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_005_003.fits pposs2ukstu_blue_005_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_005_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=55.491671&d=24.594045&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_005_004.fits pposs2ukstu_blue_005_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_005_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=55.486937&d=25.093821&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_005_005.fits pposs2ukstu_blue_005_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_005_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=55.482166&d=25.593431&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_005_006.fits pposs2ukstu_blue_005_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_006_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=54.962501&d=23.089456&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_006_001.fits pposs2ukstu_blue_006_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_006_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=54.955775&d=23.589156&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_006_002.fits pposs2ukstu_blue_006_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_006_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=54.948997&d=24.088916&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_006_003.fits pposs2ukstu_blue_006_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_006_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=54.942167&d=24.588661&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_006_004.fits pposs2ukstu_blue_006_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_006_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=54.935282&d=25.088315&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_006_005.fits pposs2ukstu_blue_006_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_blue_006_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_blue&r=54.928344&d=25.587801&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_blue_006_006.fits pposs2ukstu_blue_006_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_001_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.679435&d=23.095942&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_001_001.fits pposs2ukstu_red_001_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_001_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.683228&d=23.595801&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_001_002.fits pposs2ukstu_red_001_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_001_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.687050&d=24.095720&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_001_003.fits pposs2ukstu_red_001_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_001_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.690902&d=24.595624&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_001_004.fits pposs2ukstu_red_001_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_001_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.694784&d=25.095437&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_001_005.fits pposs2ukstu_red_001_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_001_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.698697&d=25.595083&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_001_006.fits pposs2ukstu_red_001_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_002_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.136009&d=23.098364&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_002_001.fits pposs2ukstu_red_002_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_002_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.137698&d=23.598282&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_002_002.fits pposs2ukstu_red_002_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_002_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.139400&d=24.098261&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_002_003.fits pposs2ukstu_red_002_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_002_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.141115&d=24.598224&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_002_004.fits pposs2ukstu_red_002_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_002_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.142844&d=25.098097&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_002_005.fits pposs2ukstu_red_002_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_002_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=57.144586&d=25.597802&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_002_006.fits pposs2ukstu_red_002_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_003_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.592505&d=23.098927&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_003_001.fits pposs2ukstu_red_003_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_003_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.592089&d=23.598858&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_003_002.fits pposs2ukstu_red_003_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_003_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.591670&d=24.098851&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_003_003.fits pposs2ukstu_red_003_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_003_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.591247&d=24.598828&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_003_004.fits pposs2ukstu_red_003_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_003_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.590820&d=25.098714&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_003_005.fits pposs2ukstu_red_003_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_003_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.590391&d=25.598433&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_003_006.fits pposs2ukstu_red_003_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_004_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.049021&d=23.097629&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_004_001.fits pposs2ukstu_red_004_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_004_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.046500&d=23.597528&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_004_002.fits pposs2ukstu_red_004_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_004_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.043959&d=24.097489&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_004_003.fits pposs2ukstu_red_004_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_004_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.041398&d=24.597434&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_004_004.fits pposs2ukstu_red_004_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_004_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.038818&d=25.097289&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_004_005.fits pposs2ukstu_red_004_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_004_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=56.036217&d=25.596976&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_004_006.fits pposs2ukstu_red_004_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_005_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=55.505654&d=23.094471&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_005_001.fits pposs2ukstu_red_005_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_005_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=55.501029&d=23.594293&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_005_002.fits pposs2ukstu_red_005_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_005_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=55.496368&d=24.094177&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_005_003.fits pposs2ukstu_red_005_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_005_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=55.491671&d=24.594045&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_005_004.fits pposs2ukstu_red_005_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_005_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=55.486937&d=25.093821&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_005_005.fits pposs2ukstu_red_005_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_005_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=55.482166&d=25.593431&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_005_006.fits pposs2ukstu_red_005_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_006_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=54.962501&d=23.089456&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_006_001.fits pposs2ukstu_red_006_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_006_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=54.955775&d=23.589156&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_006_002.fits pposs2ukstu_red_006_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_006_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=54.948997&d=24.088916&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_006_003.fits pposs2ukstu_red_006_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_006_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=54.942167&d=24.588661&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_006_004.fits pposs2ukstu_red_006_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_006_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=54.935282&d=25.088315&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_006_005.fits pposs2ukstu_red_006_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_red_006_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_red&r=54.928344&d=25.587801&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_red_006_006.fits pposs2ukstu_red_006_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_001_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.679435&d=23.095942&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_001_001.fits pposs2ukstu_ir_001_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_001_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.683228&d=23.595801&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_001_002.fits pposs2ukstu_ir_001_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_001_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.687050&d=24.095720&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_001_003.fits pposs2ukstu_ir_001_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_001_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.690902&d=24.595624&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_001_004.fits pposs2ukstu_ir_001_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_001_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.694784&d=25.095437&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_001_005.fits pposs2ukstu_ir_001_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_001_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.698697&d=25.595083&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_001_006.fits pposs2ukstu_ir_001_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_002_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.136009&d=23.098364&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_002_001.fits pposs2ukstu_ir_002_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_002_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.137698&d=23.598282&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_002_002.fits pposs2ukstu_ir_002_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_002_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.139400&d=24.098261&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_002_003.fits pposs2ukstu_ir_002_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_002_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.141115&d=24.598224&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_002_004.fits pposs2ukstu_ir_002_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_002_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.142844&d=25.098097&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_002_005.fits pposs2ukstu_ir_002_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_002_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=57.144586&d=25.597802&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_002_006.fits pposs2ukstu_ir_002_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_003_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.592505&d=23.098927&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_003_001.fits pposs2ukstu_ir_003_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_003_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.592089&d=23.598858&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_003_002.fits pposs2ukstu_ir_003_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_003_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.591670&d=24.098851&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_003_003.fits pposs2ukstu_ir_003_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_003_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.591247&d=24.598828&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_003_004.fits pposs2ukstu_ir_003_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_003_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.590820&d=25.098714&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_003_005.fits pposs2ukstu_ir_003_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_003_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.590391&d=25.598433&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_003_006.fits pposs2ukstu_ir_003_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_004_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.049021&d=23.097629&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_004_001.fits pposs2ukstu_ir_004_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_004_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.046500&d=23.597528&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_004_002.fits pposs2ukstu_ir_004_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_004_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.043959&d=24.097489&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_004_003.fits pposs2ukstu_ir_004_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_004_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.041398&d=24.597434&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_004_004.fits pposs2ukstu_ir_004_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_004_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.038818&d=25.097289&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_004_005.fits pposs2ukstu_ir_004_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_004_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=56.036217&d=25.596976&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_004_006.fits pposs2ukstu_ir_004_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_005_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=55.505654&d=23.094471&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_005_001.fits pposs2ukstu_ir_005_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_005_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=55.501029&d=23.594293&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_005_002.fits pposs2ukstu_ir_005_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_005_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=55.496368&d=24.094177&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_005_003.fits pposs2ukstu_ir_005_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_005_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=55.491671&d=24.594045&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_005_004.fits pposs2ukstu_ir_005_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_005_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=55.486937&d=25.093821&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_005_005.fits pposs2ukstu_ir_005_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_005_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=55.482166&d=25.593431&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_005_006.fits pposs2ukstu_ir_005_006.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_006_001.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=54.962501&d=23.089456&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_006_001.fits pposs2ukstu_ir_006_001.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_006_002.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=54.955775&d=23.589156&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_006_002.fits pposs2ukstu_ir_006_002.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_006_003.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=54.948997&d=24.088916&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_006_003.fits pposs2ukstu_ir_006_003.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_006_004.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=54.942167&d=24.588661&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_006_004.fits pposs2ukstu_ir_006_004.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_006_005.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=54.935282&d=25.088315&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_006_005.fits pposs2ukstu_ir_006_005.fits region-oversized.hdr 
/bin/curl -L -o poss2ukstu_ir_006_006.fits 'http://archive.stsci.edu/cgi-bin/dss_search?v=poss2ukstu_ir&r=54.928344&d=25.587801&e=J2000&w=42.60&h=42.60&f=fits&c=gz'
$MONTAGE_PATH/bin/mProject -X poss2ukstu_ir_006_006.fits pposs2ukstu_ir_006_006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000019.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_004_001.fits 1-diff.000001.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000021.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_004_003.fits 1-diff.000001.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000010.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_002_004.fits 1-diff.000001.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000029.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_005_005.fits 1-diff.000001.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000031.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_006_001.fits 1-diff.000001.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000027.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_005_003.fits 1-diff.000001.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000013.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_003_001.fits 1-diff.000001.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000025.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_005_001.fits 1-diff.000001.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000011.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_002_005.fits 1-diff.000001.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000023.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_004_005.fits 1-diff.000001.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000036.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_006_006.fits 1-diff.000001.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000035.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_006_005.fits 1-diff.000001.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000008.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_002_002.fits 1-diff.000001.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000024.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_004_006.fits 1-diff.000001.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000032.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_006_002.fits 1-diff.000001.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000034.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_006_004.fits 1-diff.000001.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000004.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_001_004.fits 1-diff.000001.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000003.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_001_003.fits 1-diff.000001.000003.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000014.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_003_002.fits 1-diff.000001.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000022.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_004_004.fits 1-diff.000001.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000018.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_003_006.fits 1-diff.000001.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000020.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_004_002.fits 1-diff.000001.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000016.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_003_004.fits 1-diff.000001.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000002.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_001_002.fits 1-diff.000001.000002.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000030.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_005_006.fits 1-diff.000001.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000026.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_005_002.fits 1-diff.000001.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000012.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_002_006.fits 1-diff.000001.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000007.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_002_001.fits 1-diff.000001.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000006.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_001_006.fits 1-diff.000001.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000015.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_003_003.fits 1-diff.000001.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000017.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_003_005.fits 1-diff.000001.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000033.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_006_003.fits 1-diff.000001.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000005.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_001_005.fits 1-diff.000001.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000028.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_005_004.fits 1-diff.000001.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000001.000009.txt pposs2ukstu_blue_001_001.fits pposs2ukstu_blue_002_003.fits 1-diff.000001.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000030.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_005_006.fits 1-diff.000002.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000031.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_006_001.fits 1-diff.000002.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000016.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_003_004.fits 1-diff.000002.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000033.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_006_003.fits 1-diff.000002.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000028.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_005_004.fits 1-diff.000002.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000036.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_006_006.fits 1-diff.000002.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000032.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_006_002.fits 1-diff.000002.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000008.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_002_002.fits 1-diff.000002.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000018.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_003_006.fits 1-diff.000002.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000006.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_001_006.fits 1-diff.000002.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000035.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_006_005.fits 1-diff.000002.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000026.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_005_002.fits 1-diff.000002.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000022.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_004_004.fits 1-diff.000002.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000003.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_001_003.fits 1-diff.000002.000003.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000009.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_002_003.fits 1-diff.000002.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000020.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_004_002.fits 1-diff.000002.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000015.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_003_003.fits 1-diff.000002.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000025.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_005_001.fits 1-diff.000002.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000013.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_003_001.fits 1-diff.000002.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000023.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_004_005.fits 1-diff.000002.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000007.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_002_001.fits 1-diff.000002.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000024.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_004_006.fits 1-diff.000002.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000021.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_004_003.fits 1-diff.000002.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000011.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_002_005.fits 1-diff.000002.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000010.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_002_004.fits 1-diff.000002.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000014.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_003_002.fits 1-diff.000002.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000004.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_001_004.fits 1-diff.000002.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000027.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_005_003.fits 1-diff.000002.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000012.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_002_006.fits 1-diff.000002.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000019.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_004_001.fits 1-diff.000002.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000029.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_005_005.fits 1-diff.000002.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000005.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_001_005.fits 1-diff.000002.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000017.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_003_005.fits 1-diff.000002.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000002.000034.txt pposs2ukstu_blue_001_002.fits pposs2ukstu_blue_006_004.fits 1-diff.000002.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000027.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_005_003.fits 1-diff.000003.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000007.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_002_001.fits 1-diff.000003.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000021.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_004_003.fits 1-diff.000003.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000018.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_003_006.fits 1-diff.000003.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000015.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_003_003.fits 1-diff.000003.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000004.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_001_004.fits 1-diff.000003.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000031.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_006_001.fits 1-diff.000003.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000033.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_006_003.fits 1-diff.000003.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000035.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_006_005.fits 1-diff.000003.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000009.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_002_003.fits 1-diff.000003.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000012.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_002_006.fits 1-diff.000003.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000013.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_003_001.fits 1-diff.000003.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000005.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_001_005.fits 1-diff.000003.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000028.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_005_004.fits 1-diff.000003.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000025.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_005_001.fits 1-diff.000003.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000019.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_004_001.fits 1-diff.000003.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000036.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_006_006.fits 1-diff.000003.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000020.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_004_002.fits 1-diff.000003.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000024.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_004_006.fits 1-diff.000003.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000026.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_005_002.fits 1-diff.000003.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000032.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_006_002.fits 1-diff.000003.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000010.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_002_004.fits 1-diff.000003.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000023.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_004_005.fits 1-diff.000003.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000016.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_003_004.fits 1-diff.000003.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000006.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_001_006.fits 1-diff.000003.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000034.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_006_004.fits 1-diff.000003.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000011.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_002_005.fits 1-diff.000003.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000029.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_005_005.fits 1-diff.000003.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000017.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_003_005.fits 1-diff.000003.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000022.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_004_004.fits 1-diff.000003.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000008.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_002_002.fits 1-diff.000003.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000030.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_005_006.fits 1-diff.000003.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000003.000014.txt pposs2ukstu_blue_001_003.fits pposs2ukstu_blue_003_002.fits 1-diff.000003.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000005.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_001_005.fits 1-diff.000004.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000009.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_002_003.fits 1-diff.000004.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000017.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_003_005.fits 1-diff.000004.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000029.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_005_005.fits 1-diff.000004.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000023.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_004_005.fits 1-diff.000004.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000019.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_004_001.fits 1-diff.000004.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000033.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_006_003.fits 1-diff.000004.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000022.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_004_004.fits 1-diff.000004.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000011.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_002_005.fits 1-diff.000004.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000024.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_004_006.fits 1-diff.000004.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000030.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_005_006.fits 1-diff.000004.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000028.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_005_004.fits 1-diff.000004.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000008.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_002_002.fits 1-diff.000004.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000013.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_003_001.fits 1-diff.000004.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000035.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_006_005.fits 1-diff.000004.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000016.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_003_004.fits 1-diff.000004.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000021.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_004_003.fits 1-diff.000004.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000036.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_006_006.fits 1-diff.000004.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000025.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_005_001.fits 1-diff.000004.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000015.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_003_003.fits 1-diff.000004.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000031.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_006_001.fits 1-diff.000004.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000018.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_003_006.fits 1-diff.000004.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000012.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_002_006.fits 1-diff.000004.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000027.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_005_003.fits 1-diff.000004.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000010.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_002_004.fits 1-diff.000004.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000034.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_006_004.fits 1-diff.000004.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000032.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_006_002.fits 1-diff.000004.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000007.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_002_001.fits 1-diff.000004.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000014.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_003_002.fits 1-diff.000004.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000006.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_001_006.fits 1-diff.000004.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000026.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_005_002.fits 1-diff.000004.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000004.000020.txt pposs2ukstu_blue_001_004.fits pposs2ukstu_blue_004_002.fits 1-diff.000004.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000033.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_006_003.fits 1-diff.000005.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000015.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_003_003.fits 1-diff.000005.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000023.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_004_005.fits 1-diff.000005.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000026.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_005_002.fits 1-diff.000005.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000016.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_003_004.fits 1-diff.000005.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000031.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_006_001.fits 1-diff.000005.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000011.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_002_005.fits 1-diff.000005.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000034.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_006_004.fits 1-diff.000005.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000021.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_004_003.fits 1-diff.000005.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000006.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_001_006.fits 1-diff.000005.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000014.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_003_002.fits 1-diff.000005.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000010.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_002_004.fits 1-diff.000005.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000028.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_005_004.fits 1-diff.000005.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000012.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_002_006.fits 1-diff.000005.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000030.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_005_006.fits 1-diff.000005.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000035.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_006_005.fits 1-diff.000005.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000019.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_004_001.fits 1-diff.000005.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000018.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_003_006.fits 1-diff.000005.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000013.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_003_001.fits 1-diff.000005.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000024.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_004_006.fits 1-diff.000005.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000017.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_003_005.fits 1-diff.000005.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000009.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_002_003.fits 1-diff.000005.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000025.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_005_001.fits 1-diff.000005.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000032.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_006_002.fits 1-diff.000005.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000027.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_005_003.fits 1-diff.000005.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000036.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_006_006.fits 1-diff.000005.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000029.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_005_005.fits 1-diff.000005.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000020.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_004_002.fits 1-diff.000005.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000022.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_004_004.fits 1-diff.000005.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000007.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_002_001.fits 1-diff.000005.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000005.000008.txt pposs2ukstu_blue_001_005.fits pposs2ukstu_blue_002_002.fits 1-diff.000005.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000010.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_002_004.fits 1-diff.000006.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000007.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_002_001.fits 1-diff.000006.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000013.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_003_001.fits 1-diff.000006.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000029.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_005_005.fits 1-diff.000006.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000019.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_004_001.fits 1-diff.000006.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000032.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_006_002.fits 1-diff.000006.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000023.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_004_005.fits 1-diff.000006.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000011.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_002_005.fits 1-diff.000006.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000008.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_002_002.fits 1-diff.000006.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000020.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_004_002.fits 1-diff.000006.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000016.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_003_004.fits 1-diff.000006.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000031.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_006_001.fits 1-diff.000006.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000021.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_004_003.fits 1-diff.000006.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000012.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_002_006.fits 1-diff.000006.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000036.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_006_006.fits 1-diff.000006.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000017.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_003_005.fits 1-diff.000006.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000024.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_004_006.fits 1-diff.000006.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000026.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_005_002.fits 1-diff.000006.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000022.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_004_004.fits 1-diff.000006.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000030.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_005_006.fits 1-diff.000006.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000028.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_005_004.fits 1-diff.000006.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000018.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_003_006.fits 1-diff.000006.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000009.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_002_003.fits 1-diff.000006.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000027.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_005_003.fits 1-diff.000006.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000014.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_003_002.fits 1-diff.000006.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000015.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_003_003.fits 1-diff.000006.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000035.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_006_005.fits 1-diff.000006.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000033.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_006_003.fits 1-diff.000006.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000025.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_005_001.fits 1-diff.000006.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000006.000034.txt pposs2ukstu_blue_001_006.fits pposs2ukstu_blue_006_004.fits 1-diff.000006.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000025.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_005_001.fits 1-diff.000007.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000015.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_003_003.fits 1-diff.000007.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000008.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_002_002.fits 1-diff.000007.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000026.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_005_002.fits 1-diff.000007.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000031.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_006_001.fits 1-diff.000007.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000033.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_006_003.fits 1-diff.000007.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000022.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_004_004.fits 1-diff.000007.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000029.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_005_005.fits 1-diff.000007.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000014.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_003_002.fits 1-diff.000007.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000011.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_002_005.fits 1-diff.000007.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000027.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_005_003.fits 1-diff.000007.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000019.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_004_001.fits 1-diff.000007.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000023.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_004_005.fits 1-diff.000007.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000012.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_002_006.fits 1-diff.000007.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000010.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_002_004.fits 1-diff.000007.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000028.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_005_004.fits 1-diff.000007.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000034.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_006_004.fits 1-diff.000007.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000035.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_006_005.fits 1-diff.000007.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000009.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_002_003.fits 1-diff.000007.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000032.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_006_002.fits 1-diff.000007.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000030.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_005_006.fits 1-diff.000007.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000016.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_003_004.fits 1-diff.000007.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000024.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_004_006.fits 1-diff.000007.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000021.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_004_003.fits 1-diff.000007.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000020.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_004_002.fits 1-diff.000007.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000013.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_003_001.fits 1-diff.000007.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000017.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_003_005.fits 1-diff.000007.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000018.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_003_006.fits 1-diff.000007.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000007.000036.txt pposs2ukstu_blue_002_001.fits pposs2ukstu_blue_006_006.fits 1-diff.000007.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000035.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_006_005.fits 1-diff.000008.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000028.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_005_004.fits 1-diff.000008.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000025.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_005_001.fits 1-diff.000008.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000021.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_004_003.fits 1-diff.000008.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000010.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_002_004.fits 1-diff.000008.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000012.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_002_006.fits 1-diff.000008.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000009.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_002_003.fits 1-diff.000008.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000030.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_005_006.fits 1-diff.000008.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000011.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_002_005.fits 1-diff.000008.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000022.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_004_004.fits 1-diff.000008.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000036.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_006_006.fits 1-diff.000008.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000017.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_003_005.fits 1-diff.000008.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000016.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_003_004.fits 1-diff.000008.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000019.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_004_001.fits 1-diff.000008.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000034.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_006_004.fits 1-diff.000008.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000026.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_005_002.fits 1-diff.000008.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000024.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_004_006.fits 1-diff.000008.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000023.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_004_005.fits 1-diff.000008.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000015.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_003_003.fits 1-diff.000008.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000029.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_005_005.fits 1-diff.000008.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000033.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_006_003.fits 1-diff.000008.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000018.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_003_006.fits 1-diff.000008.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000032.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_006_002.fits 1-diff.000008.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000020.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_004_002.fits 1-diff.000008.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000014.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_003_002.fits 1-diff.000008.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000013.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_003_001.fits 1-diff.000008.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000027.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_005_003.fits 1-diff.000008.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000008.000031.txt pposs2ukstu_blue_002_002.fits pposs2ukstu_blue_006_001.fits 1-diff.000008.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000013.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_003_001.fits 1-diff.000009.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000022.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_004_004.fits 1-diff.000009.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000018.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_003_006.fits 1-diff.000009.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000024.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_004_006.fits 1-diff.000009.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000036.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_006_006.fits 1-diff.000009.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000025.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_005_001.fits 1-diff.000009.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000023.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_004_005.fits 1-diff.000009.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000035.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_006_005.fits 1-diff.000009.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000030.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_005_006.fits 1-diff.000009.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000010.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_002_004.fits 1-diff.000009.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000029.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_005_005.fits 1-diff.000009.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000026.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_005_002.fits 1-diff.000009.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000015.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_003_003.fits 1-diff.000009.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000011.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_002_005.fits 1-diff.000009.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000033.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_006_003.fits 1-diff.000009.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000019.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_004_001.fits 1-diff.000009.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000016.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_003_004.fits 1-diff.000009.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000028.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_005_004.fits 1-diff.000009.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000021.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_004_003.fits 1-diff.000009.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000034.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_006_004.fits 1-diff.000009.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000027.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_005_003.fits 1-diff.000009.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000032.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_006_002.fits 1-diff.000009.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000031.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_006_001.fits 1-diff.000009.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000020.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_004_002.fits 1-diff.000009.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000017.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_003_005.fits 1-diff.000009.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000014.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_003_002.fits 1-diff.000009.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000009.000012.txt pposs2ukstu_blue_002_003.fits pposs2ukstu_blue_002_006.fits 1-diff.000009.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000028.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_005_004.fits 1-diff.000010.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000016.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_003_004.fits 1-diff.000010.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000027.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_005_003.fits 1-diff.000010.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000012.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_002_006.fits 1-diff.000010.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000035.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_006_005.fits 1-diff.000010.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000021.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_004_003.fits 1-diff.000010.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000011.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_002_005.fits 1-diff.000010.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000019.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_004_001.fits 1-diff.000010.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000017.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_003_005.fits 1-diff.000010.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000030.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_005_006.fits 1-diff.000010.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000018.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_003_006.fits 1-diff.000010.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000034.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_006_004.fits 1-diff.000010.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000015.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_003_003.fits 1-diff.000010.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000026.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_005_002.fits 1-diff.000010.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000036.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_006_006.fits 1-diff.000010.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000025.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_005_001.fits 1-diff.000010.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000022.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_004_004.fits 1-diff.000010.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000031.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_006_001.fits 1-diff.000010.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000029.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_005_005.fits 1-diff.000010.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000023.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_004_005.fits 1-diff.000010.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000013.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_003_001.fits 1-diff.000010.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000032.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_006_002.fits 1-diff.000010.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000024.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_004_006.fits 1-diff.000010.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000014.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_003_002.fits 1-diff.000010.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000020.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_004_002.fits 1-diff.000010.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000010.000033.txt pposs2ukstu_blue_002_004.fits pposs2ukstu_blue_006_003.fits 1-diff.000010.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000032.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_006_002.fits 1-diff.000011.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000015.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_003_003.fits 1-diff.000011.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000017.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_003_005.fits 1-diff.000011.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000035.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_006_005.fits 1-diff.000011.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000034.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_006_004.fits 1-diff.000011.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000014.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_003_002.fits 1-diff.000011.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000016.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_003_004.fits 1-diff.000011.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000022.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_004_004.fits 1-diff.000011.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000012.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_002_006.fits 1-diff.000011.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000020.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_004_002.fits 1-diff.000011.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000019.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_004_001.fits 1-diff.000011.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000031.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_006_001.fits 1-diff.000011.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000018.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_003_006.fits 1-diff.000011.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000023.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_004_005.fits 1-diff.000011.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000021.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_004_003.fits 1-diff.000011.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000027.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_005_003.fits 1-diff.000011.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000033.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_006_003.fits 1-diff.000011.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000029.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_005_005.fits 1-diff.000011.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000024.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_004_006.fits 1-diff.000011.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000026.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_005_002.fits 1-diff.000011.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000013.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_003_001.fits 1-diff.000011.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000030.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_005_006.fits 1-diff.000011.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000025.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_005_001.fits 1-diff.000011.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000028.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_005_004.fits 1-diff.000011.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000011.000036.txt pposs2ukstu_blue_002_005.fits pposs2ukstu_blue_006_006.fits 1-diff.000011.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000014.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_003_002.fits 1-diff.000012.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000028.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_005_004.fits 1-diff.000012.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000013.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_003_001.fits 1-diff.000012.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000021.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_004_003.fits 1-diff.000012.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000025.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_005_001.fits 1-diff.000012.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000029.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_005_005.fits 1-diff.000012.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000022.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_004_004.fits 1-diff.000012.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000032.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_006_002.fits 1-diff.000012.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000027.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_005_003.fits 1-diff.000012.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000017.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_003_005.fits 1-diff.000012.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000035.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_006_005.fits 1-diff.000012.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000020.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_004_002.fits 1-diff.000012.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000024.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_004_006.fits 1-diff.000012.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000023.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_004_005.fits 1-diff.000012.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000019.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_004_001.fits 1-diff.000012.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000018.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_003_006.fits 1-diff.000012.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000033.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_006_003.fits 1-diff.000012.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000016.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_003_004.fits 1-diff.000012.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000034.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_006_004.fits 1-diff.000012.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000026.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_005_002.fits 1-diff.000012.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000036.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_006_006.fits 1-diff.000012.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000015.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_003_003.fits 1-diff.000012.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000030.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_005_006.fits 1-diff.000012.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000012.000031.txt pposs2ukstu_blue_002_006.fits pposs2ukstu_blue_006_001.fits 1-diff.000012.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000032.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_006_002.fits 1-diff.000013.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000035.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_006_005.fits 1-diff.000013.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000031.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_006_001.fits 1-diff.000013.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000024.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_004_006.fits 1-diff.000013.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000027.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_005_003.fits 1-diff.000013.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000029.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_005_005.fits 1-diff.000013.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000023.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_004_005.fits 1-diff.000013.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000033.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_006_003.fits 1-diff.000013.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000020.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_004_002.fits 1-diff.000013.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000016.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_003_004.fits 1-diff.000013.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000014.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_003_002.fits 1-diff.000013.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000030.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_005_006.fits 1-diff.000013.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000022.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_004_004.fits 1-diff.000013.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000019.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_004_001.fits 1-diff.000013.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000017.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_003_005.fits 1-diff.000013.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000026.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_005_002.fits 1-diff.000013.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000021.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_004_003.fits 1-diff.000013.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000018.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_003_006.fits 1-diff.000013.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000036.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_006_006.fits 1-diff.000013.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000028.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_005_004.fits 1-diff.000013.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000025.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_005_001.fits 1-diff.000013.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000034.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_006_004.fits 1-diff.000013.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000013.000015.txt pposs2ukstu_blue_003_001.fits pposs2ukstu_blue_003_003.fits 1-diff.000013.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000016.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_003_004.fits 1-diff.000014.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000031.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_006_001.fits 1-diff.000014.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000033.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_006_003.fits 1-diff.000014.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000017.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_003_005.fits 1-diff.000014.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000019.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_004_001.fits 1-diff.000014.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000027.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_005_003.fits 1-diff.000014.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000032.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_006_002.fits 1-diff.000014.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000034.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_006_004.fits 1-diff.000014.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000036.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_006_006.fits 1-diff.000014.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000026.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_005_002.fits 1-diff.000014.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000022.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_004_004.fits 1-diff.000014.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000020.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_004_002.fits 1-diff.000014.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000030.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_005_006.fits 1-diff.000014.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000018.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_003_006.fits 1-diff.000014.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000029.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_005_005.fits 1-diff.000014.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000015.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_003_003.fits 1-diff.000014.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000024.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_004_006.fits 1-diff.000014.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000025.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_005_001.fits 1-diff.000014.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000021.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_004_003.fits 1-diff.000014.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000035.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_006_005.fits 1-diff.000014.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000023.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_004_005.fits 1-diff.000014.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000014.000028.txt pposs2ukstu_blue_003_002.fits pposs2ukstu_blue_005_004.fits 1-diff.000014.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000021.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_004_003.fits 1-diff.000015.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000023.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_004_005.fits 1-diff.000015.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000036.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_006_006.fits 1-diff.000015.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000022.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_004_004.fits 1-diff.000015.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000016.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_003_004.fits 1-diff.000015.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000026.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_005_002.fits 1-diff.000015.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000019.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_004_001.fits 1-diff.000015.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000027.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_005_003.fits 1-diff.000015.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000029.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_005_005.fits 1-diff.000015.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000034.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_006_004.fits 1-diff.000015.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000018.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_003_006.fits 1-diff.000015.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000032.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_006_002.fits 1-diff.000015.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000035.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_006_005.fits 1-diff.000015.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000025.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_005_001.fits 1-diff.000015.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000033.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_006_003.fits 1-diff.000015.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000020.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_004_002.fits 1-diff.000015.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000030.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_005_006.fits 1-diff.000015.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000028.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_005_004.fits 1-diff.000015.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000024.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_004_006.fits 1-diff.000015.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000017.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_003_005.fits 1-diff.000015.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000015.000031.txt pposs2ukstu_blue_003_003.fits pposs2ukstu_blue_006_001.fits 1-diff.000015.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000019.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_004_001.fits 1-diff.000016.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000036.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_006_006.fits 1-diff.000016.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000028.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_005_004.fits 1-diff.000016.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000033.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_006_003.fits 1-diff.000016.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000027.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_005_003.fits 1-diff.000016.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000024.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_004_006.fits 1-diff.000016.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000032.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_006_002.fits 1-diff.000016.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000021.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_004_003.fits 1-diff.000016.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000034.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_006_004.fits 1-diff.000016.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000022.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_004_004.fits 1-diff.000016.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000031.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_006_001.fits 1-diff.000016.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000025.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_005_001.fits 1-diff.000016.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000035.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_006_005.fits 1-diff.000016.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000018.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_003_006.fits 1-diff.000016.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000030.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_005_006.fits 1-diff.000016.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000029.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_005_005.fits 1-diff.000016.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000023.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_004_005.fits 1-diff.000016.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000020.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_004_002.fits 1-diff.000016.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000026.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_005_002.fits 1-diff.000016.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000016.000017.txt pposs2ukstu_blue_003_004.fits pposs2ukstu_blue_003_005.fits 1-diff.000016.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000032.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_006_002.fits 1-diff.000017.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000036.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_006_006.fits 1-diff.000017.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000033.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_006_003.fits 1-diff.000017.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000018.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_003_006.fits 1-diff.000017.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000023.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_004_005.fits 1-diff.000017.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000024.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_004_006.fits 1-diff.000017.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000020.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_004_002.fits 1-diff.000017.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000022.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_004_004.fits 1-diff.000017.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000035.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_006_005.fits 1-diff.000017.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000031.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_006_001.fits 1-diff.000017.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000025.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_005_001.fits 1-diff.000017.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000029.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_005_005.fits 1-diff.000017.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000030.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_005_006.fits 1-diff.000017.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000034.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_006_004.fits 1-diff.000017.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000027.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_005_003.fits 1-diff.000017.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000019.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_004_001.fits 1-diff.000017.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000026.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_005_002.fits 1-diff.000017.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000021.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_004_003.fits 1-diff.000017.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000017.000028.txt pposs2ukstu_blue_003_005.fits pposs2ukstu_blue_005_004.fits 1-diff.000017.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000021.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_004_003.fits 1-diff.000018.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000024.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_004_006.fits 1-diff.000018.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000032.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_006_002.fits 1-diff.000018.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000030.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_005_006.fits 1-diff.000018.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000034.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_006_004.fits 1-diff.000018.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000022.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_004_004.fits 1-diff.000018.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000027.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_005_003.fits 1-diff.000018.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000029.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_005_005.fits 1-diff.000018.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000028.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_005_004.fits 1-diff.000018.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000020.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_004_002.fits 1-diff.000018.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000036.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_006_006.fits 1-diff.000018.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000033.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_006_003.fits 1-diff.000018.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000031.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_006_001.fits 1-diff.000018.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000035.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_006_005.fits 1-diff.000018.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000019.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_004_001.fits 1-diff.000018.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000025.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_005_001.fits 1-diff.000018.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000026.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_005_002.fits 1-diff.000018.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000018.000023.txt pposs2ukstu_blue_003_006.fits pposs2ukstu_blue_004_005.fits 1-diff.000018.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000030.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_005_006.fits 1-diff.000019.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000028.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_005_004.fits 1-diff.000019.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000034.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_006_004.fits 1-diff.000019.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000036.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_006_006.fits 1-diff.000019.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000035.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_006_005.fits 1-diff.000019.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000024.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_004_006.fits 1-diff.000019.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000033.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_006_003.fits 1-diff.000019.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000029.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_005_005.fits 1-diff.000019.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000025.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_005_001.fits 1-diff.000019.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000020.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_004_002.fits 1-diff.000019.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000021.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_004_003.fits 1-diff.000019.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000023.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_004_005.fits 1-diff.000019.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000031.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_006_001.fits 1-diff.000019.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000027.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_005_003.fits 1-diff.000019.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000022.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_004_004.fits 1-diff.000019.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000026.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_005_002.fits 1-diff.000019.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000019.000032.txt pposs2ukstu_blue_004_001.fits pposs2ukstu_blue_006_002.fits 1-diff.000019.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000030.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_005_006.fits 1-diff.000020.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000031.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_006_001.fits 1-diff.000020.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000029.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_005_005.fits 1-diff.000020.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000024.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_004_006.fits 1-diff.000020.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000022.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_004_004.fits 1-diff.000020.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000026.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_005_002.fits 1-diff.000020.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000027.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_005_003.fits 1-diff.000020.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000032.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_006_002.fits 1-diff.000020.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000025.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_005_001.fits 1-diff.000020.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000023.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_004_005.fits 1-diff.000020.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000021.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_004_003.fits 1-diff.000020.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000028.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_005_004.fits 1-diff.000020.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000033.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_006_003.fits 1-diff.000020.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000035.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_006_005.fits 1-diff.000020.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000036.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_006_006.fits 1-diff.000020.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000020.000034.txt pposs2ukstu_blue_004_002.fits pposs2ukstu_blue_006_004.fits 1-diff.000020.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000031.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_006_001.fits 1-diff.000021.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000023.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_004_005.fits 1-diff.000021.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000030.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_005_006.fits 1-diff.000021.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000022.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_004_004.fits 1-diff.000021.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000034.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_006_004.fits 1-diff.000021.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000036.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_006_006.fits 1-diff.000021.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000032.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_006_002.fits 1-diff.000021.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000026.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_005_002.fits 1-diff.000021.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000025.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_005_001.fits 1-diff.000021.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000035.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_006_005.fits 1-diff.000021.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000029.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_005_005.fits 1-diff.000021.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000024.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_004_006.fits 1-diff.000021.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000033.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_006_003.fits 1-diff.000021.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000028.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_005_004.fits 1-diff.000021.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000021.000027.txt pposs2ukstu_blue_004_003.fits pposs2ukstu_blue_005_003.fits 1-diff.000021.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000032.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_006_002.fits 1-diff.000022.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000031.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_006_001.fits 1-diff.000022.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000033.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_006_003.fits 1-diff.000022.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000029.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_005_005.fits 1-diff.000022.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000030.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_005_006.fits 1-diff.000022.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000034.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_006_004.fits 1-diff.000022.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000028.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_005_004.fits 1-diff.000022.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000036.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_006_006.fits 1-diff.000022.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000035.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_006_005.fits 1-diff.000022.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000025.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_005_001.fits 1-diff.000022.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000027.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_005_003.fits 1-diff.000022.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000026.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_005_002.fits 1-diff.000022.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000024.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_004_006.fits 1-diff.000022.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000022.000023.txt pposs2ukstu_blue_004_004.fits pposs2ukstu_blue_004_005.fits 1-diff.000022.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000034.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_006_004.fits 1-diff.000023.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000026.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_005_002.fits 1-diff.000023.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000029.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_005_005.fits 1-diff.000023.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000035.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_006_005.fits 1-diff.000023.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000025.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_005_001.fits 1-diff.000023.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000033.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_006_003.fits 1-diff.000023.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000031.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_006_001.fits 1-diff.000023.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000036.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_006_006.fits 1-diff.000023.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000030.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_005_006.fits 1-diff.000023.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000028.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_005_004.fits 1-diff.000023.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000027.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_005_003.fits 1-diff.000023.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000032.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_006_002.fits 1-diff.000023.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000023.000024.txt pposs2ukstu_blue_004_005.fits pposs2ukstu_blue_004_006.fits 1-diff.000023.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000029.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_005_005.fits 1-diff.000024.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000025.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_005_001.fits 1-diff.000024.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000035.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_006_005.fits 1-diff.000024.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000034.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_006_004.fits 1-diff.000024.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000031.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_006_001.fits 1-diff.000024.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000033.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_006_003.fits 1-diff.000024.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000030.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_005_006.fits 1-diff.000024.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000027.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_005_003.fits 1-diff.000024.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000036.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_006_006.fits 1-diff.000024.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000026.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_005_002.fits 1-diff.000024.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000032.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_006_002.fits 1-diff.000024.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000024.000028.txt pposs2ukstu_blue_004_006.fits pposs2ukstu_blue_005_004.fits 1-diff.000024.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000033.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_006_003.fits 1-diff.000025.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000031.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_006_001.fits 1-diff.000025.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000032.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_006_002.fits 1-diff.000025.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000030.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_005_006.fits 1-diff.000025.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000036.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_006_006.fits 1-diff.000025.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000026.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_005_002.fits 1-diff.000025.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000034.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_006_004.fits 1-diff.000025.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000035.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_006_005.fits 1-diff.000025.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000027.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_005_003.fits 1-diff.000025.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000028.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_005_004.fits 1-diff.000025.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000025.000029.txt pposs2ukstu_blue_005_001.fits pposs2ukstu_blue_005_005.fits 1-diff.000025.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000036.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_006_006.fits 1-diff.000026.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000034.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_006_004.fits 1-diff.000026.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000032.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_006_002.fits 1-diff.000026.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000031.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_006_001.fits 1-diff.000026.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000030.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_005_006.fits 1-diff.000026.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000029.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_005_005.fits 1-diff.000026.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000035.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_006_005.fits 1-diff.000026.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000033.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_006_003.fits 1-diff.000026.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000027.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_005_003.fits 1-diff.000026.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000026.000028.txt pposs2ukstu_blue_005_002.fits pposs2ukstu_blue_005_004.fits 1-diff.000026.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000030.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_005_006.fits 1-diff.000027.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000029.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_005_005.fits 1-diff.000027.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000032.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_006_002.fits 1-diff.000027.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000031.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_006_001.fits 1-diff.000027.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000034.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_006_004.fits 1-diff.000027.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000028.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_005_004.fits 1-diff.000027.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000035.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_006_005.fits 1-diff.000027.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000033.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_006_003.fits 1-diff.000027.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000027.000036.txt pposs2ukstu_blue_005_003.fits pposs2ukstu_blue_006_006.fits 1-diff.000027.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000032.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_006_002.fits 1-diff.000028.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000031.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_006_001.fits 1-diff.000028.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000030.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_005_006.fits 1-diff.000028.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000034.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_006_004.fits 1-diff.000028.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000036.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_006_006.fits 1-diff.000028.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000035.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_006_005.fits 1-diff.000028.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000029.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_005_005.fits 1-diff.000028.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000028.000033.txt pposs2ukstu_blue_005_004.fits pposs2ukstu_blue_006_003.fits 1-diff.000028.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000036.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_006_006.fits 1-diff.000029.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000035.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_006_005.fits 1-diff.000029.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000032.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_006_002.fits 1-diff.000029.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000034.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_006_004.fits 1-diff.000029.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000030.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_005_006.fits 1-diff.000029.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000031.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_006_001.fits 1-diff.000029.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000029.000033.txt pposs2ukstu_blue_005_005.fits pposs2ukstu_blue_006_003.fits 1-diff.000029.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000030.000032.txt pposs2ukstu_blue_005_006.fits pposs2ukstu_blue_006_002.fits 1-diff.000030.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000030.000031.txt pposs2ukstu_blue_005_006.fits pposs2ukstu_blue_006_001.fits 1-diff.000030.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000030.000033.txt pposs2ukstu_blue_005_006.fits pposs2ukstu_blue_006_003.fits 1-diff.000030.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000030.000036.txt pposs2ukstu_blue_005_006.fits pposs2ukstu_blue_006_006.fits 1-diff.000030.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000030.000035.txt pposs2ukstu_blue_005_006.fits pposs2ukstu_blue_006_005.fits 1-diff.000030.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000030.000034.txt pposs2ukstu_blue_005_006.fits pposs2ukstu_blue_006_004.fits 1-diff.000030.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000031.000032.txt pposs2ukstu_blue_006_001.fits pposs2ukstu_blue_006_002.fits 1-diff.000031.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000031.000033.txt pposs2ukstu_blue_006_001.fits pposs2ukstu_blue_006_003.fits 1-diff.000031.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000031.000034.txt pposs2ukstu_blue_006_001.fits pposs2ukstu_blue_006_004.fits 1-diff.000031.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000031.000035.txt pposs2ukstu_blue_006_001.fits pposs2ukstu_blue_006_005.fits 1-diff.000031.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000031.000036.txt pposs2ukstu_blue_006_001.fits pposs2ukstu_blue_006_006.fits 1-diff.000031.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000032.000035.txt pposs2ukstu_blue_006_002.fits pposs2ukstu_blue_006_005.fits 1-diff.000032.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000032.000034.txt pposs2ukstu_blue_006_002.fits pposs2ukstu_blue_006_004.fits 1-diff.000032.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000032.000036.txt pposs2ukstu_blue_006_002.fits pposs2ukstu_blue_006_006.fits 1-diff.000032.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000032.000033.txt pposs2ukstu_blue_006_002.fits pposs2ukstu_blue_006_003.fits 1-diff.000032.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000033.000036.txt pposs2ukstu_blue_006_003.fits pposs2ukstu_blue_006_006.fits 1-diff.000033.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000033.000035.txt pposs2ukstu_blue_006_003.fits pposs2ukstu_blue_006_005.fits 1-diff.000033.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000033.000034.txt pposs2ukstu_blue_006_003.fits pposs2ukstu_blue_006_004.fits 1-diff.000033.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000034.000035.txt pposs2ukstu_blue_006_004.fits pposs2ukstu_blue_006_005.fits 1-diff.000034.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000034.000036.txt pposs2ukstu_blue_006_004.fits pposs2ukstu_blue_006_006.fits 1-diff.000034.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 1-fit.000035.000036.txt pposs2ukstu_blue_006_005.fits pposs2ukstu_blue_006_006.fits 1-diff.000035.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000027.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_005_003.fits 2-diff.000001.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000032.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_006_002.fits 2-diff.000001.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000021.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_004_003.fits 2-diff.000001.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000004.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_001_004.fits 2-diff.000001.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000031.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_006_001.fits 2-diff.000001.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000010.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_002_004.fits 2-diff.000001.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000035.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_006_005.fits 2-diff.000001.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000036.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_006_006.fits 2-diff.000001.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000026.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_005_002.fits 2-diff.000001.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000003.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_001_003.fits 2-diff.000001.000003.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000034.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_006_004.fits 2-diff.000001.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000015.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_003_003.fits 2-diff.000001.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000030.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_005_006.fits 2-diff.000001.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000012.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_002_006.fits 2-diff.000001.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000018.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_003_006.fits 2-diff.000001.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000014.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_003_002.fits 2-diff.000001.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000023.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_004_005.fits 2-diff.000001.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000017.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_003_005.fits 2-diff.000001.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000020.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_004_002.fits 2-diff.000001.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000028.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_005_004.fits 2-diff.000001.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000011.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_002_005.fits 2-diff.000001.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000006.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_001_006.fits 2-diff.000001.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000005.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_001_005.fits 2-diff.000001.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000024.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_004_006.fits 2-diff.000001.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000029.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_005_005.fits 2-diff.000001.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000033.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_006_003.fits 2-diff.000001.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000009.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_002_003.fits 2-diff.000001.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000025.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_005_001.fits 2-diff.000001.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000019.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_004_001.fits 2-diff.000001.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000002.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_001_002.fits 2-diff.000001.000002.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000008.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_002_002.fits 2-diff.000001.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000016.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_003_004.fits 2-diff.000001.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000007.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_002_001.fits 2-diff.000001.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000013.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_003_001.fits 2-diff.000001.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000001.000022.txt pposs2ukstu_red_001_001.fits pposs2ukstu_red_004_004.fits 2-diff.000001.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000035.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_006_005.fits 2-diff.000002.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000020.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_004_002.fits 2-diff.000002.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000006.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_001_006.fits 2-diff.000002.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000026.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_005_002.fits 2-diff.000002.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000009.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_002_003.fits 2-diff.000002.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000033.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_006_003.fits 2-diff.000002.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000022.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_004_004.fits 2-diff.000002.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000014.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_003_002.fits 2-diff.000002.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000036.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_006_006.fits 2-diff.000002.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000008.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_002_002.fits 2-diff.000002.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000017.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_003_005.fits 2-diff.000002.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000034.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_006_004.fits 2-diff.000002.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000023.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_004_005.fits 2-diff.000002.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000032.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_006_002.fits 2-diff.000002.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000010.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_002_004.fits 2-diff.000002.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000019.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_004_001.fits 2-diff.000002.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000004.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_001_004.fits 2-diff.000002.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000030.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_005_006.fits 2-diff.000002.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000013.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_003_001.fits 2-diff.000002.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000028.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_005_004.fits 2-diff.000002.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000012.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_002_006.fits 2-diff.000002.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000011.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_002_005.fits 2-diff.000002.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000031.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_006_001.fits 2-diff.000002.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000018.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_003_006.fits 2-diff.000002.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000024.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_004_006.fits 2-diff.000002.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000007.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_002_001.fits 2-diff.000002.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000027.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_005_003.fits 2-diff.000002.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000015.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_003_003.fits 2-diff.000002.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000005.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_001_005.fits 2-diff.000002.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000021.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_004_003.fits 2-diff.000002.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000025.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_005_001.fits 2-diff.000002.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000029.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_005_005.fits 2-diff.000002.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000016.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_003_004.fits 2-diff.000002.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000002.000003.txt pposs2ukstu_red_001_002.fits pposs2ukstu_red_001_003.fits 2-diff.000002.000003.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000005.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_001_005.fits 2-diff.000003.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000033.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_006_003.fits 2-diff.000003.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000012.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_002_006.fits 2-diff.000003.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000014.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_003_002.fits 2-diff.000003.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000007.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_002_001.fits 2-diff.000003.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000006.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_001_006.fits 2-diff.000003.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000036.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_006_006.fits 2-diff.000003.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000024.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_004_006.fits 2-diff.000003.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000011.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_002_005.fits 2-diff.000003.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000027.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_005_003.fits 2-diff.000003.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000026.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_005_002.fits 2-diff.000003.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000016.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_003_004.fits 2-diff.000003.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000025.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_005_001.fits 2-diff.000003.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000020.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_004_002.fits 2-diff.000003.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000031.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_006_001.fits 2-diff.000003.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000019.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_004_001.fits 2-diff.000003.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000008.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_002_002.fits 2-diff.000003.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000021.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_004_003.fits 2-diff.000003.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000017.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_003_005.fits 2-diff.000003.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000015.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_003_003.fits 2-diff.000003.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000010.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_002_004.fits 2-diff.000003.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000022.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_004_004.fits 2-diff.000003.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000030.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_005_006.fits 2-diff.000003.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000023.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_004_005.fits 2-diff.000003.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000009.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_002_003.fits 2-diff.000003.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000018.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_003_006.fits 2-diff.000003.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000032.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_006_002.fits 2-diff.000003.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000034.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_006_004.fits 2-diff.000003.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000029.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_005_005.fits 2-diff.000003.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000028.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_005_004.fits 2-diff.000003.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000004.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_001_004.fits 2-diff.000003.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000013.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_003_001.fits 2-diff.000003.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000003.000035.txt pposs2ukstu_red_001_003.fits pposs2ukstu_red_006_005.fits 2-diff.000003.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000035.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_006_005.fits 2-diff.000004.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000006.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_001_006.fits 2-diff.000004.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000025.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_005_001.fits 2-diff.000004.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000007.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_002_001.fits 2-diff.000004.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000010.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_002_004.fits 2-diff.000004.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000033.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_006_003.fits 2-diff.000004.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000022.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_004_004.fits 2-diff.000004.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000021.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_004_003.fits 2-diff.000004.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000019.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_004_001.fits 2-diff.000004.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000030.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_005_006.fits 2-diff.000004.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000018.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_003_006.fits 2-diff.000004.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000026.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_005_002.fits 2-diff.000004.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000031.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_006_001.fits 2-diff.000004.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000034.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_006_004.fits 2-diff.000004.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000016.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_003_004.fits 2-diff.000004.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000029.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_005_005.fits 2-diff.000004.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000015.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_003_003.fits 2-diff.000004.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000020.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_004_002.fits 2-diff.000004.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000023.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_004_005.fits 2-diff.000004.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000028.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_005_004.fits 2-diff.000004.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000036.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_006_006.fits 2-diff.000004.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000017.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_003_005.fits 2-diff.000004.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000012.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_002_006.fits 2-diff.000004.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000011.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_002_005.fits 2-diff.000004.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000032.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_006_002.fits 2-diff.000004.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000013.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_003_001.fits 2-diff.000004.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000008.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_002_002.fits 2-diff.000004.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000014.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_003_002.fits 2-diff.000004.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000024.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_004_006.fits 2-diff.000004.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000009.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_002_003.fits 2-diff.000004.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000027.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_005_003.fits 2-diff.000004.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000004.000005.txt pposs2ukstu_red_001_004.fits pposs2ukstu_red_001_005.fits 2-diff.000004.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000014.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_003_002.fits 2-diff.000005.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000030.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_005_006.fits 2-diff.000005.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000016.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_003_004.fits 2-diff.000005.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000025.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_005_001.fits 2-diff.000005.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000012.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_002_006.fits 2-diff.000005.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000022.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_004_004.fits 2-diff.000005.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000023.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_004_005.fits 2-diff.000005.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000027.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_005_003.fits 2-diff.000005.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000029.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_005_005.fits 2-diff.000005.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000035.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_006_005.fits 2-diff.000005.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000008.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_002_002.fits 2-diff.000005.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000013.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_003_001.fits 2-diff.000005.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000020.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_004_002.fits 2-diff.000005.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000026.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_005_002.fits 2-diff.000005.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000019.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_004_001.fits 2-diff.000005.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000028.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_005_004.fits 2-diff.000005.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000006.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_001_006.fits 2-diff.000005.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000024.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_004_006.fits 2-diff.000005.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000021.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_004_003.fits 2-diff.000005.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000015.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_003_003.fits 2-diff.000005.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000031.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_006_001.fits 2-diff.000005.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000034.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_006_004.fits 2-diff.000005.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000018.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_003_006.fits 2-diff.000005.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000033.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_006_003.fits 2-diff.000005.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000017.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_003_005.fits 2-diff.000005.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000009.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_002_003.fits 2-diff.000005.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000011.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_002_005.fits 2-diff.000005.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000032.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_006_002.fits 2-diff.000005.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000007.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_002_001.fits 2-diff.000005.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000010.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_002_004.fits 2-diff.000005.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000005.000036.txt pposs2ukstu_red_001_005.fits pposs2ukstu_red_006_006.fits 2-diff.000005.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000016.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_003_004.fits 2-diff.000006.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000017.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_003_005.fits 2-diff.000006.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000018.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_003_006.fits 2-diff.000006.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000036.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_006_006.fits 2-diff.000006.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000027.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_005_003.fits 2-diff.000006.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000007.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_002_001.fits 2-diff.000006.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000028.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_005_004.fits 2-diff.000006.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000011.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_002_005.fits 2-diff.000006.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000025.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_005_001.fits 2-diff.000006.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000020.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_004_002.fits 2-diff.000006.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000023.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_004_005.fits 2-diff.000006.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000033.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_006_003.fits 2-diff.000006.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000026.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_005_002.fits 2-diff.000006.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000015.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_003_003.fits 2-diff.000006.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000010.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_002_004.fits 2-diff.000006.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000019.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_004_001.fits 2-diff.000006.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000030.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_005_006.fits 2-diff.000006.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000013.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_003_001.fits 2-diff.000006.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000029.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_005_005.fits 2-diff.000006.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000009.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_002_003.fits 2-diff.000006.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000032.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_006_002.fits 2-diff.000006.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000031.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_006_001.fits 2-diff.000006.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000012.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_002_006.fits 2-diff.000006.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000008.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_002_002.fits 2-diff.000006.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000035.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_006_005.fits 2-diff.000006.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000024.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_004_006.fits 2-diff.000006.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000021.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_004_003.fits 2-diff.000006.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000034.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_006_004.fits 2-diff.000006.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000022.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_004_004.fits 2-diff.000006.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000006.000014.txt pposs2ukstu_red_001_006.fits pposs2ukstu_red_003_002.fits 2-diff.000006.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000008.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_002_002.fits 2-diff.000007.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000025.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_005_001.fits 2-diff.000007.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000014.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_003_002.fits 2-diff.000007.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000011.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_002_005.fits 2-diff.000007.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000009.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_002_003.fits 2-diff.000007.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000032.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_006_002.fits 2-diff.000007.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000013.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_003_001.fits 2-diff.000007.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000018.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_003_006.fits 2-diff.000007.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000023.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_004_005.fits 2-diff.000007.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000036.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_006_006.fits 2-diff.000007.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000033.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_006_003.fits 2-diff.000007.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000028.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_005_004.fits 2-diff.000007.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000027.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_005_003.fits 2-diff.000007.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000034.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_006_004.fits 2-diff.000007.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000019.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_004_001.fits 2-diff.000007.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000022.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_004_004.fits 2-diff.000007.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000021.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_004_003.fits 2-diff.000007.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000015.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_003_003.fits 2-diff.000007.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000030.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_005_006.fits 2-diff.000007.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000026.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_005_002.fits 2-diff.000007.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000024.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_004_006.fits 2-diff.000007.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000031.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_006_001.fits 2-diff.000007.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000017.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_003_005.fits 2-diff.000007.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000035.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_006_005.fits 2-diff.000007.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000010.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_002_004.fits 2-diff.000007.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000020.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_004_002.fits 2-diff.000007.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000016.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_003_004.fits 2-diff.000007.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000012.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_002_006.fits 2-diff.000007.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000007.000029.txt pposs2ukstu_red_002_001.fits pposs2ukstu_red_005_005.fits 2-diff.000007.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000019.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_004_001.fits 2-diff.000008.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000033.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_006_003.fits 2-diff.000008.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000025.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_005_001.fits 2-diff.000008.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000020.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_004_002.fits 2-diff.000008.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000027.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_005_003.fits 2-diff.000008.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000015.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_003_003.fits 2-diff.000008.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000028.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_005_004.fits 2-diff.000008.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000029.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_005_005.fits 2-diff.000008.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000036.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_006_006.fits 2-diff.000008.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000012.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_002_006.fits 2-diff.000008.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000035.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_006_005.fits 2-diff.000008.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000013.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_003_001.fits 2-diff.000008.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000018.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_003_006.fits 2-diff.000008.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000016.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_003_004.fits 2-diff.000008.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000030.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_005_006.fits 2-diff.000008.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000023.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_004_005.fits 2-diff.000008.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000011.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_002_005.fits 2-diff.000008.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000024.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_004_006.fits 2-diff.000008.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000026.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_005_002.fits 2-diff.000008.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000032.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_006_002.fits 2-diff.000008.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000031.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_006_001.fits 2-diff.000008.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000014.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_003_002.fits 2-diff.000008.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000010.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_002_004.fits 2-diff.000008.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000009.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_002_003.fits 2-diff.000008.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000017.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_003_005.fits 2-diff.000008.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000021.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_004_003.fits 2-diff.000008.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000022.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_004_004.fits 2-diff.000008.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000008.000034.txt pposs2ukstu_red_002_002.fits pposs2ukstu_red_006_004.fits 2-diff.000008.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000027.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_005_003.fits 2-diff.000009.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000026.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_005_002.fits 2-diff.000009.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000029.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_005_005.fits 2-diff.000009.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000024.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_004_006.fits 2-diff.000009.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000030.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_005_006.fits 2-diff.000009.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000021.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_004_003.fits 2-diff.000009.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000032.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_006_002.fits 2-diff.000009.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000013.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_003_001.fits 2-diff.000009.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000017.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_003_005.fits 2-diff.000009.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000014.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_003_002.fits 2-diff.000009.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000022.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_004_004.fits 2-diff.000009.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000025.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_005_001.fits 2-diff.000009.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000023.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_004_005.fits 2-diff.000009.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000010.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_002_004.fits 2-diff.000009.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000016.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_003_004.fits 2-diff.000009.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000011.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_002_005.fits 2-diff.000009.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000020.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_004_002.fits 2-diff.000009.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000036.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_006_006.fits 2-diff.000009.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000018.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_003_006.fits 2-diff.000009.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000019.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_004_001.fits 2-diff.000009.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000015.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_003_003.fits 2-diff.000009.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000033.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_006_003.fits 2-diff.000009.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000012.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_002_006.fits 2-diff.000009.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000031.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_006_001.fits 2-diff.000009.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000035.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_006_005.fits 2-diff.000009.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000034.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_006_004.fits 2-diff.000009.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000009.000028.txt pposs2ukstu_red_002_003.fits pposs2ukstu_red_005_004.fits 2-diff.000009.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000029.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_005_005.fits 2-diff.000010.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000032.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_006_002.fits 2-diff.000010.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000019.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_004_001.fits 2-diff.000010.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000022.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_004_004.fits 2-diff.000010.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000035.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_006_005.fits 2-diff.000010.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000012.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_002_006.fits 2-diff.000010.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000011.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_002_005.fits 2-diff.000010.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000023.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_004_005.fits 2-diff.000010.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000026.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_005_002.fits 2-diff.000010.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000021.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_004_003.fits 2-diff.000010.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000025.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_005_001.fits 2-diff.000010.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000015.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_003_003.fits 2-diff.000010.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000033.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_006_003.fits 2-diff.000010.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000034.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_006_004.fits 2-diff.000010.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000017.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_003_005.fits 2-diff.000010.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000014.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_003_002.fits 2-diff.000010.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000018.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_003_006.fits 2-diff.000010.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000030.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_005_006.fits 2-diff.000010.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000013.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_003_001.fits 2-diff.000010.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000027.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_005_003.fits 2-diff.000010.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000024.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_004_006.fits 2-diff.000010.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000020.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_004_002.fits 2-diff.000010.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000031.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_006_001.fits 2-diff.000010.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000016.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_003_004.fits 2-diff.000010.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000036.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_006_006.fits 2-diff.000010.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000010.000028.txt pposs2ukstu_red_002_004.fits pposs2ukstu_red_005_004.fits 2-diff.000010.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000031.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_006_001.fits 2-diff.000011.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000023.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_004_005.fits 2-diff.000011.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000024.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_004_006.fits 2-diff.000011.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000025.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_005_001.fits 2-diff.000011.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000022.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_004_004.fits 2-diff.000011.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000034.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_006_004.fits 2-diff.000011.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000018.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_003_006.fits 2-diff.000011.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000019.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_004_001.fits 2-diff.000011.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000029.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_005_005.fits 2-diff.000011.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000033.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_006_003.fits 2-diff.000011.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000026.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_005_002.fits 2-diff.000011.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000028.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_005_004.fits 2-diff.000011.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000020.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_004_002.fits 2-diff.000011.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000016.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_003_004.fits 2-diff.000011.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000017.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_003_005.fits 2-diff.000011.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000013.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_003_001.fits 2-diff.000011.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000027.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_005_003.fits 2-diff.000011.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000030.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_005_006.fits 2-diff.000011.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000035.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_006_005.fits 2-diff.000011.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000032.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_006_002.fits 2-diff.000011.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000014.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_003_002.fits 2-diff.000011.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000036.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_006_006.fits 2-diff.000011.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000015.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_003_003.fits 2-diff.000011.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000021.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_004_003.fits 2-diff.000011.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000011.000012.txt pposs2ukstu_red_002_005.fits pposs2ukstu_red_002_006.fits 2-diff.000011.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000014.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_003_002.fits 2-diff.000012.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000016.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_003_004.fits 2-diff.000012.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000026.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_005_002.fits 2-diff.000012.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000013.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_003_001.fits 2-diff.000012.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000028.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_005_004.fits 2-diff.000012.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000018.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_003_006.fits 2-diff.000012.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000035.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_006_005.fits 2-diff.000012.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000015.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_003_003.fits 2-diff.000012.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000019.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_004_001.fits 2-diff.000012.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000033.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_006_003.fits 2-diff.000012.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000021.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_004_003.fits 2-diff.000012.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000031.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_006_001.fits 2-diff.000012.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000023.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_004_005.fits 2-diff.000012.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000030.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_005_006.fits 2-diff.000012.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000017.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_003_005.fits 2-diff.000012.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000029.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_005_005.fits 2-diff.000012.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000024.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_004_006.fits 2-diff.000012.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000027.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_005_003.fits 2-diff.000012.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000025.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_005_001.fits 2-diff.000012.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000034.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_006_004.fits 2-diff.000012.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000020.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_004_002.fits 2-diff.000012.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000022.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_004_004.fits 2-diff.000012.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000036.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_006_006.fits 2-diff.000012.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000012.000032.txt pposs2ukstu_red_002_006.fits pposs2ukstu_red_006_002.fits 2-diff.000012.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000014.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_003_002.fits 2-diff.000013.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000028.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_005_004.fits 2-diff.000013.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000030.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_005_006.fits 2-diff.000013.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000017.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_003_005.fits 2-diff.000013.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000020.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_004_002.fits 2-diff.000013.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000027.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_005_003.fits 2-diff.000013.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000022.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_004_004.fits 2-diff.000013.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000026.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_005_002.fits 2-diff.000013.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000034.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_006_004.fits 2-diff.000013.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000036.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_006_006.fits 2-diff.000013.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000032.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_006_002.fits 2-diff.000013.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000035.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_006_005.fits 2-diff.000013.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000023.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_004_005.fits 2-diff.000013.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000016.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_003_004.fits 2-diff.000013.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000033.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_006_003.fits 2-diff.000013.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000015.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_003_003.fits 2-diff.000013.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000018.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_003_006.fits 2-diff.000013.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000019.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_004_001.fits 2-diff.000013.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000021.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_004_003.fits 2-diff.000013.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000029.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_005_005.fits 2-diff.000013.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000025.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_005_001.fits 2-diff.000013.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000024.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_004_006.fits 2-diff.000013.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000013.000031.txt pposs2ukstu_red_003_001.fits pposs2ukstu_red_006_001.fits 2-diff.000013.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000016.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_003_004.fits 2-diff.000014.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000024.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_004_006.fits 2-diff.000014.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000031.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_006_001.fits 2-diff.000014.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000036.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_006_006.fits 2-diff.000014.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000027.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_005_003.fits 2-diff.000014.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000023.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_004_005.fits 2-diff.000014.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000022.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_004_004.fits 2-diff.000014.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000020.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_004_002.fits 2-diff.000014.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000018.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_003_006.fits 2-diff.000014.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000021.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_004_003.fits 2-diff.000014.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000019.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_004_001.fits 2-diff.000014.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000017.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_003_005.fits 2-diff.000014.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000033.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_006_003.fits 2-diff.000014.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000029.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_005_005.fits 2-diff.000014.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000030.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_005_006.fits 2-diff.000014.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000026.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_005_002.fits 2-diff.000014.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000032.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_006_002.fits 2-diff.000014.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000035.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_006_005.fits 2-diff.000014.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000028.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_005_004.fits 2-diff.000014.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000025.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_005_001.fits 2-diff.000014.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000034.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_006_004.fits 2-diff.000014.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000014.000015.txt pposs2ukstu_red_003_002.fits pposs2ukstu_red_003_003.fits 2-diff.000014.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000027.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_005_003.fits 2-diff.000015.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000031.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_006_001.fits 2-diff.000015.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000034.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_006_004.fits 2-diff.000015.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000025.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_005_001.fits 2-diff.000015.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000021.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_004_003.fits 2-diff.000015.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000024.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_004_006.fits 2-diff.000015.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000035.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_006_005.fits 2-diff.000015.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000020.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_004_002.fits 2-diff.000015.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000026.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_005_002.fits 2-diff.000015.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000033.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_006_003.fits 2-diff.000015.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000019.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_004_001.fits 2-diff.000015.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000036.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_006_006.fits 2-diff.000015.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000030.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_005_006.fits 2-diff.000015.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000022.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_004_004.fits 2-diff.000015.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000029.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_005_005.fits 2-diff.000015.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000016.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_003_004.fits 2-diff.000015.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000017.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_003_005.fits 2-diff.000015.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000018.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_003_006.fits 2-diff.000015.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000028.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_005_004.fits 2-diff.000015.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000032.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_006_002.fits 2-diff.000015.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000015.000023.txt pposs2ukstu_red_003_003.fits pposs2ukstu_red_004_005.fits 2-diff.000015.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000030.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_005_006.fits 2-diff.000016.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000026.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_005_002.fits 2-diff.000016.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000036.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_006_006.fits 2-diff.000016.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000025.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_005_001.fits 2-diff.000016.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000031.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_006_001.fits 2-diff.000016.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000017.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_003_005.fits 2-diff.000016.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000018.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_003_006.fits 2-diff.000016.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000022.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_004_004.fits 2-diff.000016.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000021.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_004_003.fits 2-diff.000016.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000027.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_005_003.fits 2-diff.000016.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000028.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_005_004.fits 2-diff.000016.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000020.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_004_002.fits 2-diff.000016.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000029.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_005_005.fits 2-diff.000016.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000019.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_004_001.fits 2-diff.000016.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000035.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_006_005.fits 2-diff.000016.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000032.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_006_002.fits 2-diff.000016.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000034.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_006_004.fits 2-diff.000016.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000024.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_004_006.fits 2-diff.000016.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000023.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_004_005.fits 2-diff.000016.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000016.000033.txt pposs2ukstu_red_003_004.fits pposs2ukstu_red_006_003.fits 2-diff.000016.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000026.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_005_002.fits 2-diff.000017.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000034.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_006_004.fits 2-diff.000017.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000024.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_004_006.fits 2-diff.000017.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000028.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_005_004.fits 2-diff.000017.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000025.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_005_001.fits 2-diff.000017.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000023.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_004_005.fits 2-diff.000017.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000018.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_003_006.fits 2-diff.000017.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000036.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_006_006.fits 2-diff.000017.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000031.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_006_001.fits 2-diff.000017.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000030.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_005_006.fits 2-diff.000017.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000019.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_004_001.fits 2-diff.000017.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000020.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_004_002.fits 2-diff.000017.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000021.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_004_003.fits 2-diff.000017.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000027.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_005_003.fits 2-diff.000017.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000022.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_004_004.fits 2-diff.000017.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000029.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_005_005.fits 2-diff.000017.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000035.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_006_005.fits 2-diff.000017.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000032.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_006_002.fits 2-diff.000017.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000017.000033.txt pposs2ukstu_red_003_005.fits pposs2ukstu_red_006_003.fits 2-diff.000017.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000020.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_004_002.fits 2-diff.000018.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000023.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_004_005.fits 2-diff.000018.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000030.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_005_006.fits 2-diff.000018.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000036.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_006_006.fits 2-diff.000018.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000022.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_004_004.fits 2-diff.000018.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000031.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_006_001.fits 2-diff.000018.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000033.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_006_003.fits 2-diff.000018.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000024.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_004_006.fits 2-diff.000018.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000025.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_005_001.fits 2-diff.000018.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000028.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_005_004.fits 2-diff.000018.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000035.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_006_005.fits 2-diff.000018.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000027.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_005_003.fits 2-diff.000018.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000034.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_006_004.fits 2-diff.000018.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000032.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_006_002.fits 2-diff.000018.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000019.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_004_001.fits 2-diff.000018.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000026.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_005_002.fits 2-diff.000018.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000029.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_005_005.fits 2-diff.000018.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000018.000021.txt pposs2ukstu_red_003_006.fits pposs2ukstu_red_004_003.fits 2-diff.000018.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000021.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_004_003.fits 2-diff.000019.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000029.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_005_005.fits 2-diff.000019.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000033.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_006_003.fits 2-diff.000019.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000034.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_006_004.fits 2-diff.000019.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000032.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_006_002.fits 2-diff.000019.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000026.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_005_002.fits 2-diff.000019.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000035.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_006_005.fits 2-diff.000019.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000020.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_004_002.fits 2-diff.000019.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000036.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_006_006.fits 2-diff.000019.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000022.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_004_004.fits 2-diff.000019.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000031.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_006_001.fits 2-diff.000019.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000030.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_005_006.fits 2-diff.000019.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000024.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_004_006.fits 2-diff.000019.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000023.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_004_005.fits 2-diff.000019.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000027.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_005_003.fits 2-diff.000019.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000028.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_005_004.fits 2-diff.000019.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000019.000025.txt pposs2ukstu_red_004_001.fits pposs2ukstu_red_005_001.fits 2-diff.000019.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000024.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_004_006.fits 2-diff.000020.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000022.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_004_004.fits 2-diff.000020.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000025.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_005_001.fits 2-diff.000020.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000030.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_005_006.fits 2-diff.000020.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000031.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_006_001.fits 2-diff.000020.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000036.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_006_006.fits 2-diff.000020.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000028.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_005_004.fits 2-diff.000020.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000033.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_006_003.fits 2-diff.000020.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000026.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_005_002.fits 2-diff.000020.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000035.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_006_005.fits 2-diff.000020.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000023.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_004_005.fits 2-diff.000020.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000034.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_006_004.fits 2-diff.000020.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000032.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_006_002.fits 2-diff.000020.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000029.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_005_005.fits 2-diff.000020.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000021.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_004_003.fits 2-diff.000020.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000020.000027.txt pposs2ukstu_red_004_002.fits pposs2ukstu_red_005_003.fits 2-diff.000020.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000026.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_005_002.fits 2-diff.000021.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000024.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_004_006.fits 2-diff.000021.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000029.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_005_005.fits 2-diff.000021.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000027.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_005_003.fits 2-diff.000021.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000033.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_006_003.fits 2-diff.000021.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000030.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_005_006.fits 2-diff.000021.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000036.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_006_006.fits 2-diff.000021.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000023.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_004_005.fits 2-diff.000021.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000035.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_006_005.fits 2-diff.000021.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000022.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_004_004.fits 2-diff.000021.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000025.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_005_001.fits 2-diff.000021.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000031.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_006_001.fits 2-diff.000021.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000032.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_006_002.fits 2-diff.000021.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000034.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_006_004.fits 2-diff.000021.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000021.000028.txt pposs2ukstu_red_004_003.fits pposs2ukstu_red_005_004.fits 2-diff.000021.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000035.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_006_005.fits 2-diff.000022.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000036.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_006_006.fits 2-diff.000022.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000034.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_006_004.fits 2-diff.000022.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000026.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_005_002.fits 2-diff.000022.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000023.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_004_005.fits 2-diff.000022.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000030.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_005_006.fits 2-diff.000022.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000033.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_006_003.fits 2-diff.000022.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000024.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_004_006.fits 2-diff.000022.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000027.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_005_003.fits 2-diff.000022.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000032.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_006_002.fits 2-diff.000022.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000031.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_006_001.fits 2-diff.000022.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000025.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_005_001.fits 2-diff.000022.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000029.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_005_005.fits 2-diff.000022.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000022.000028.txt pposs2ukstu_red_004_004.fits pposs2ukstu_red_005_004.fits 2-diff.000022.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000024.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_004_006.fits 2-diff.000023.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000030.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_005_006.fits 2-diff.000023.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000032.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_006_002.fits 2-diff.000023.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000034.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_006_004.fits 2-diff.000023.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000035.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_006_005.fits 2-diff.000023.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000025.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_005_001.fits 2-diff.000023.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000031.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_006_001.fits 2-diff.000023.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000027.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_005_003.fits 2-diff.000023.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000028.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_005_004.fits 2-diff.000023.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000029.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_005_005.fits 2-diff.000023.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000036.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_006_006.fits 2-diff.000023.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000026.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_005_002.fits 2-diff.000023.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000023.000033.txt pposs2ukstu_red_004_005.fits pposs2ukstu_red_006_003.fits 2-diff.000023.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000036.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_006_006.fits 2-diff.000024.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000029.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_005_005.fits 2-diff.000024.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000034.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_006_004.fits 2-diff.000024.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000028.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_005_004.fits 2-diff.000024.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000026.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_005_002.fits 2-diff.000024.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000030.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_005_006.fits 2-diff.000024.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000035.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_006_005.fits 2-diff.000024.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000033.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_006_003.fits 2-diff.000024.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000027.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_005_003.fits 2-diff.000024.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000032.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_006_002.fits 2-diff.000024.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000025.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_005_001.fits 2-diff.000024.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000024.000031.txt pposs2ukstu_red_004_006.fits pposs2ukstu_red_006_001.fits 2-diff.000024.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000029.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_005_005.fits 2-diff.000025.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000026.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_005_002.fits 2-diff.000025.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000031.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_006_001.fits 2-diff.000025.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000035.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_006_005.fits 2-diff.000025.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000033.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_006_003.fits 2-diff.000025.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000034.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_006_004.fits 2-diff.000025.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000036.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_006_006.fits 2-diff.000025.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000032.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_006_002.fits 2-diff.000025.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000030.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_005_006.fits 2-diff.000025.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000028.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_005_004.fits 2-diff.000025.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000025.000027.txt pposs2ukstu_red_005_001.fits pposs2ukstu_red_005_003.fits 2-diff.000025.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000028.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_005_004.fits 2-diff.000026.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000034.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_006_004.fits 2-diff.000026.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000033.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_006_003.fits 2-diff.000026.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000036.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_006_006.fits 2-diff.000026.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000027.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_005_003.fits 2-diff.000026.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000031.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_006_001.fits 2-diff.000026.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000035.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_006_005.fits 2-diff.000026.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000030.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_005_006.fits 2-diff.000026.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000029.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_005_005.fits 2-diff.000026.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000026.000032.txt pposs2ukstu_red_005_002.fits pposs2ukstu_red_006_002.fits 2-diff.000026.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000028.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_005_004.fits 2-diff.000027.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000029.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_005_005.fits 2-diff.000027.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000033.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_006_003.fits 2-diff.000027.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000031.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_006_001.fits 2-diff.000027.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000034.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_006_004.fits 2-diff.000027.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000035.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_006_005.fits 2-diff.000027.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000032.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_006_002.fits 2-diff.000027.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000036.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_006_006.fits 2-diff.000027.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000027.000030.txt pposs2ukstu_red_005_003.fits pposs2ukstu_red_005_006.fits 2-diff.000027.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000030.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_005_006.fits 2-diff.000028.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000033.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_006_003.fits 2-diff.000028.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000035.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_006_005.fits 2-diff.000028.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000036.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_006_006.fits 2-diff.000028.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000034.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_006_004.fits 2-diff.000028.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000031.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_006_001.fits 2-diff.000028.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000029.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_005_005.fits 2-diff.000028.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000028.000032.txt pposs2ukstu_red_005_004.fits pposs2ukstu_red_006_002.fits 2-diff.000028.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000036.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_006_006.fits 2-diff.000029.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000030.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_005_006.fits 2-diff.000029.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000033.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_006_003.fits 2-diff.000029.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000031.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_006_001.fits 2-diff.000029.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000032.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_006_002.fits 2-diff.000029.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000034.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_006_004.fits 2-diff.000029.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000029.000035.txt pposs2ukstu_red_005_005.fits pposs2ukstu_red_006_005.fits 2-diff.000029.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000030.000031.txt pposs2ukstu_red_005_006.fits pposs2ukstu_red_006_001.fits 2-diff.000030.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000030.000033.txt pposs2ukstu_red_005_006.fits pposs2ukstu_red_006_003.fits 2-diff.000030.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000030.000032.txt pposs2ukstu_red_005_006.fits pposs2ukstu_red_006_002.fits 2-diff.000030.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000030.000035.txt pposs2ukstu_red_005_006.fits pposs2ukstu_red_006_005.fits 2-diff.000030.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000030.000034.txt pposs2ukstu_red_005_006.fits pposs2ukstu_red_006_004.fits 2-diff.000030.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000030.000036.txt pposs2ukstu_red_005_006.fits pposs2ukstu_red_006_006.fits 2-diff.000030.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000031.000033.txt pposs2ukstu_red_006_001.fits pposs2ukstu_red_006_003.fits 2-diff.000031.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000031.000035.txt pposs2ukstu_red_006_001.fits pposs2ukstu_red_006_005.fits 2-diff.000031.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000031.000032.txt pposs2ukstu_red_006_001.fits pposs2ukstu_red_006_002.fits 2-diff.000031.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000031.000036.txt pposs2ukstu_red_006_001.fits pposs2ukstu_red_006_006.fits 2-diff.000031.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000031.000034.txt pposs2ukstu_red_006_001.fits pposs2ukstu_red_006_004.fits 2-diff.000031.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000032.000034.txt pposs2ukstu_red_006_002.fits pposs2ukstu_red_006_004.fits 2-diff.000032.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000032.000036.txt pposs2ukstu_red_006_002.fits pposs2ukstu_red_006_006.fits 2-diff.000032.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000032.000033.txt pposs2ukstu_red_006_002.fits pposs2ukstu_red_006_003.fits 2-diff.000032.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000032.000035.txt pposs2ukstu_red_006_002.fits pposs2ukstu_red_006_005.fits 2-diff.000032.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000033.000034.txt pposs2ukstu_red_006_003.fits pposs2ukstu_red_006_004.fits 2-diff.000033.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000033.000036.txt pposs2ukstu_red_006_003.fits pposs2ukstu_red_006_006.fits 2-diff.000033.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000033.000035.txt pposs2ukstu_red_006_003.fits pposs2ukstu_red_006_005.fits 2-diff.000033.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000034.000036.txt pposs2ukstu_red_006_004.fits pposs2ukstu_red_006_006.fits 2-diff.000034.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000034.000035.txt pposs2ukstu_red_006_004.fits pposs2ukstu_red_006_005.fits 2-diff.000034.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 2-fit.000035.000036.txt pposs2ukstu_red_006_005.fits pposs2ukstu_red_006_006.fits 2-diff.000035.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000021.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_004_003.fits 3-diff.000001.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000011.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_002_005.fits 3-diff.000001.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000031.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_006_001.fits 3-diff.000001.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000029.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_005_005.fits 3-diff.000001.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000008.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_002_002.fits 3-diff.000001.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000027.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_005_003.fits 3-diff.000001.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000022.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_004_004.fits 3-diff.000001.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000036.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_006_006.fits 3-diff.000001.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000035.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_006_005.fits 3-diff.000001.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000016.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_003_004.fits 3-diff.000001.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000020.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_004_002.fits 3-diff.000001.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000033.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_006_003.fits 3-diff.000001.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000030.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_005_006.fits 3-diff.000001.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000019.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_004_001.fits 3-diff.000001.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000026.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_005_002.fits 3-diff.000001.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000017.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_003_005.fits 3-diff.000001.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000025.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_005_001.fits 3-diff.000001.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000007.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_002_001.fits 3-diff.000001.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000003.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_001_003.fits 3-diff.000001.000003.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000012.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_002_006.fits 3-diff.000001.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000004.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_001_004.fits 3-diff.000001.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000018.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_003_006.fits 3-diff.000001.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000032.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_006_002.fits 3-diff.000001.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000034.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_006_004.fits 3-diff.000001.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000010.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_002_004.fits 3-diff.000001.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000009.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_002_003.fits 3-diff.000001.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000015.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_003_003.fits 3-diff.000001.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000002.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_001_002.fits 3-diff.000001.000002.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000006.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_001_006.fits 3-diff.000001.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000028.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_005_004.fits 3-diff.000001.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000023.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_004_005.fits 3-diff.000001.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000024.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_004_006.fits 3-diff.000001.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000014.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_003_002.fits 3-diff.000001.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000005.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_001_005.fits 3-diff.000001.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000001.000013.txt pposs2ukstu_ir_001_001.fits pposs2ukstu_ir_003_001.fits 3-diff.000001.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000007.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_002_001.fits 3-diff.000002.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000027.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_005_003.fits 3-diff.000002.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000022.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_004_004.fits 3-diff.000002.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000035.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_006_005.fits 3-diff.000002.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000018.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_003_006.fits 3-diff.000002.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000024.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_004_006.fits 3-diff.000002.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000006.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_001_006.fits 3-diff.000002.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000025.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_005_001.fits 3-diff.000002.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000010.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_002_004.fits 3-diff.000002.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000013.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_003_001.fits 3-diff.000002.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000011.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_002_005.fits 3-diff.000002.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000016.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_003_004.fits 3-diff.000002.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000004.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_001_004.fits 3-diff.000002.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000030.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_005_006.fits 3-diff.000002.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000031.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_006_001.fits 3-diff.000002.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000033.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_006_003.fits 3-diff.000002.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000014.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_003_002.fits 3-diff.000002.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000015.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_003_003.fits 3-diff.000002.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000032.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_006_002.fits 3-diff.000002.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000017.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_003_005.fits 3-diff.000002.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000036.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_006_006.fits 3-diff.000002.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000020.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_004_002.fits 3-diff.000002.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000012.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_002_006.fits 3-diff.000002.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000003.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_001_003.fits 3-diff.000002.000003.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000019.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_004_001.fits 3-diff.000002.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000005.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_001_005.fits 3-diff.000002.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000008.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_002_002.fits 3-diff.000002.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000026.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_005_002.fits 3-diff.000002.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000023.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_004_005.fits 3-diff.000002.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000029.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_005_005.fits 3-diff.000002.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000009.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_002_003.fits 3-diff.000002.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000028.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_005_004.fits 3-diff.000002.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000034.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_006_004.fits 3-diff.000002.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000002.000021.txt pposs2ukstu_ir_001_002.fits pposs2ukstu_ir_004_003.fits 3-diff.000002.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000036.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_006_006.fits 3-diff.000003.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000004.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_001_004.fits 3-diff.000003.000004.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000009.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_002_003.fits 3-diff.000003.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000025.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_005_001.fits 3-diff.000003.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000029.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_005_005.fits 3-diff.000003.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000006.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_001_006.fits 3-diff.000003.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000011.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_002_005.fits 3-diff.000003.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000033.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_006_003.fits 3-diff.000003.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000030.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_005_006.fits 3-diff.000003.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000007.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_002_001.fits 3-diff.000003.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000017.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_003_005.fits 3-diff.000003.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000032.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_006_002.fits 3-diff.000003.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000005.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_001_005.fits 3-diff.000003.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000035.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_006_005.fits 3-diff.000003.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000023.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_004_005.fits 3-diff.000003.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000022.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_004_004.fits 3-diff.000003.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000012.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_002_006.fits 3-diff.000003.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000028.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_005_004.fits 3-diff.000003.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000015.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_003_003.fits 3-diff.000003.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000031.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_006_001.fits 3-diff.000003.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000020.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_004_002.fits 3-diff.000003.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000010.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_002_004.fits 3-diff.000003.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000018.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_003_006.fits 3-diff.000003.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000026.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_005_002.fits 3-diff.000003.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000014.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_003_002.fits 3-diff.000003.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000034.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_006_004.fits 3-diff.000003.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000027.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_005_003.fits 3-diff.000003.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000013.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_003_001.fits 3-diff.000003.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000019.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_004_001.fits 3-diff.000003.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000021.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_004_003.fits 3-diff.000003.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000008.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_002_002.fits 3-diff.000003.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000024.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_004_006.fits 3-diff.000003.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000003.000016.txt pposs2ukstu_ir_001_003.fits pposs2ukstu_ir_003_004.fits 3-diff.000003.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000010.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_002_004.fits 3-diff.000004.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000027.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_005_003.fits 3-diff.000004.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000018.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_003_006.fits 3-diff.000004.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000033.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_006_003.fits 3-diff.000004.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000022.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_004_004.fits 3-diff.000004.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000032.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_006_002.fits 3-diff.000004.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000017.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_003_005.fits 3-diff.000004.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000014.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_003_002.fits 3-diff.000004.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000030.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_005_006.fits 3-diff.000004.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000008.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_002_002.fits 3-diff.000004.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000007.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_002_001.fits 3-diff.000004.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000015.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_003_003.fits 3-diff.000004.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000036.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_006_006.fits 3-diff.000004.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000016.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_003_004.fits 3-diff.000004.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000034.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_006_004.fits 3-diff.000004.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000021.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_004_003.fits 3-diff.000004.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000012.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_002_006.fits 3-diff.000004.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000024.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_004_006.fits 3-diff.000004.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000035.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_006_005.fits 3-diff.000004.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000006.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_001_006.fits 3-diff.000004.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000011.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_002_005.fits 3-diff.000004.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000005.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_001_005.fits 3-diff.000004.000005.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000023.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_004_005.fits 3-diff.000004.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000020.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_004_002.fits 3-diff.000004.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000031.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_006_001.fits 3-diff.000004.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000026.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_005_002.fits 3-diff.000004.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000028.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_005_004.fits 3-diff.000004.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000029.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_005_005.fits 3-diff.000004.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000025.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_005_001.fits 3-diff.000004.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000019.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_004_001.fits 3-diff.000004.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000009.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_002_003.fits 3-diff.000004.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000004.000013.txt pposs2ukstu_ir_001_004.fits pposs2ukstu_ir_003_001.fits 3-diff.000004.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000025.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_005_001.fits 3-diff.000005.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000009.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_002_003.fits 3-diff.000005.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000034.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_006_004.fits 3-diff.000005.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000014.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_003_002.fits 3-diff.000005.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000008.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_002_002.fits 3-diff.000005.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000029.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_005_005.fits 3-diff.000005.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000011.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_002_005.fits 3-diff.000005.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000026.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_005_002.fits 3-diff.000005.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000012.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_002_006.fits 3-diff.000005.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000035.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_006_005.fits 3-diff.000005.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000019.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_004_001.fits 3-diff.000005.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000030.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_005_006.fits 3-diff.000005.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000022.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_004_004.fits 3-diff.000005.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000020.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_004_002.fits 3-diff.000005.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000018.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_003_006.fits 3-diff.000005.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000010.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_002_004.fits 3-diff.000005.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000016.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_003_004.fits 3-diff.000005.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000031.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_006_001.fits 3-diff.000005.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000032.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_006_002.fits 3-diff.000005.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000006.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_001_006.fits 3-diff.000005.000006.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000033.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_006_003.fits 3-diff.000005.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000007.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_002_001.fits 3-diff.000005.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000036.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_006_006.fits 3-diff.000005.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000024.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_004_006.fits 3-diff.000005.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000013.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_003_001.fits 3-diff.000005.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000028.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_005_004.fits 3-diff.000005.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000021.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_004_003.fits 3-diff.000005.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000023.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_004_005.fits 3-diff.000005.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000017.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_003_005.fits 3-diff.000005.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000015.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_003_003.fits 3-diff.000005.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000005.000027.txt pposs2ukstu_ir_001_005.fits pposs2ukstu_ir_005_003.fits 3-diff.000005.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000035.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_006_005.fits 3-diff.000006.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000016.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_003_004.fits 3-diff.000006.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000024.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_004_006.fits 3-diff.000006.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000018.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_003_006.fits 3-diff.000006.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000010.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_002_004.fits 3-diff.000006.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000007.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_002_001.fits 3-diff.000006.000007.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000021.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_004_003.fits 3-diff.000006.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000008.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_002_002.fits 3-diff.000006.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000034.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_006_004.fits 3-diff.000006.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000017.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_003_005.fits 3-diff.000006.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000020.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_004_002.fits 3-diff.000006.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000030.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_005_006.fits 3-diff.000006.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000011.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_002_005.fits 3-diff.000006.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000009.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_002_003.fits 3-diff.000006.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000023.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_004_005.fits 3-diff.000006.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000028.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_005_004.fits 3-diff.000006.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000014.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_003_002.fits 3-diff.000006.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000019.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_004_001.fits 3-diff.000006.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000032.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_006_002.fits 3-diff.000006.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000036.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_006_006.fits 3-diff.000006.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000026.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_005_002.fits 3-diff.000006.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000031.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_006_001.fits 3-diff.000006.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000029.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_005_005.fits 3-diff.000006.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000015.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_003_003.fits 3-diff.000006.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000013.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_003_001.fits 3-diff.000006.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000033.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_006_003.fits 3-diff.000006.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000025.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_005_001.fits 3-diff.000006.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000027.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_005_003.fits 3-diff.000006.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000022.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_004_004.fits 3-diff.000006.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000006.000012.txt pposs2ukstu_ir_001_006.fits pposs2ukstu_ir_002_006.fits 3-diff.000006.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000012.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_002_006.fits 3-diff.000007.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000023.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_004_005.fits 3-diff.000007.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000009.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_002_003.fits 3-diff.000007.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000014.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_003_002.fits 3-diff.000007.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000011.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_002_005.fits 3-diff.000007.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000013.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_003_001.fits 3-diff.000007.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000028.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_005_004.fits 3-diff.000007.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000035.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_006_005.fits 3-diff.000007.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000010.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_002_004.fits 3-diff.000007.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000024.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_004_006.fits 3-diff.000007.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000033.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_006_003.fits 3-diff.000007.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000022.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_004_004.fits 3-diff.000007.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000020.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_004_002.fits 3-diff.000007.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000032.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_006_002.fits 3-diff.000007.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000025.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_005_001.fits 3-diff.000007.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000016.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_003_004.fits 3-diff.000007.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000030.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_005_006.fits 3-diff.000007.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000034.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_006_004.fits 3-diff.000007.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000029.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_005_005.fits 3-diff.000007.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000026.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_005_002.fits 3-diff.000007.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000031.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_006_001.fits 3-diff.000007.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000021.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_004_003.fits 3-diff.000007.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000015.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_003_003.fits 3-diff.000007.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000008.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_002_002.fits 3-diff.000007.000008.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000036.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_006_006.fits 3-diff.000007.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000027.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_005_003.fits 3-diff.000007.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000017.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_003_005.fits 3-diff.000007.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000018.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_003_006.fits 3-diff.000007.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000007.000019.txt pposs2ukstu_ir_002_001.fits pposs2ukstu_ir_004_001.fits 3-diff.000007.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000009.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_002_003.fits 3-diff.000008.000009.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000020.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_004_002.fits 3-diff.000008.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000012.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_002_006.fits 3-diff.000008.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000018.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_003_006.fits 3-diff.000008.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000029.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_005_005.fits 3-diff.000008.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000031.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_006_001.fits 3-diff.000008.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000034.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_006_004.fits 3-diff.000008.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000027.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_005_003.fits 3-diff.000008.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000010.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_002_004.fits 3-diff.000008.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000033.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_006_003.fits 3-diff.000008.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000025.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_005_001.fits 3-diff.000008.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000024.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_004_006.fits 3-diff.000008.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000015.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_003_003.fits 3-diff.000008.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000030.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_005_006.fits 3-diff.000008.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000017.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_003_005.fits 3-diff.000008.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000014.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_003_002.fits 3-diff.000008.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000035.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_006_005.fits 3-diff.000008.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000028.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_005_004.fits 3-diff.000008.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000011.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_002_005.fits 3-diff.000008.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000016.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_003_004.fits 3-diff.000008.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000013.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_003_001.fits 3-diff.000008.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000021.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_004_003.fits 3-diff.000008.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000019.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_004_001.fits 3-diff.000008.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000032.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_006_002.fits 3-diff.000008.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000036.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_006_006.fits 3-diff.000008.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000023.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_004_005.fits 3-diff.000008.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000022.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_004_004.fits 3-diff.000008.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000008.000026.txt pposs2ukstu_ir_002_002.fits pposs2ukstu_ir_005_002.fits 3-diff.000008.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000016.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_003_004.fits 3-diff.000009.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000018.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_003_006.fits 3-diff.000009.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000019.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_004_001.fits 3-diff.000009.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000035.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_006_005.fits 3-diff.000009.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000026.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_005_002.fits 3-diff.000009.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000013.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_003_001.fits 3-diff.000009.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000028.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_005_004.fits 3-diff.000009.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000022.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_004_004.fits 3-diff.000009.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000025.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_005_001.fits 3-diff.000009.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000015.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_003_003.fits 3-diff.000009.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000036.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_006_006.fits 3-diff.000009.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000034.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_006_004.fits 3-diff.000009.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000021.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_004_003.fits 3-diff.000009.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000020.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_004_002.fits 3-diff.000009.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000030.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_005_006.fits 3-diff.000009.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000032.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_006_002.fits 3-diff.000009.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000033.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_006_003.fits 3-diff.000009.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000029.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_005_005.fits 3-diff.000009.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000014.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_003_002.fits 3-diff.000009.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000017.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_003_005.fits 3-diff.000009.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000011.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_002_005.fits 3-diff.000009.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000031.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_006_001.fits 3-diff.000009.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000012.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_002_006.fits 3-diff.000009.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000024.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_004_006.fits 3-diff.000009.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000023.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_004_005.fits 3-diff.000009.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000027.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_005_003.fits 3-diff.000009.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000009.000010.txt pposs2ukstu_ir_002_003.fits pposs2ukstu_ir_002_004.fits 3-diff.000009.000010.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000028.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_005_004.fits 3-diff.000010.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000014.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_003_002.fits 3-diff.000010.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000033.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_006_003.fits 3-diff.000010.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000036.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_006_006.fits 3-diff.000010.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000034.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_006_004.fits 3-diff.000010.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000013.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_003_001.fits 3-diff.000010.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000035.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_006_005.fits 3-diff.000010.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000025.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_005_001.fits 3-diff.000010.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000021.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_004_003.fits 3-diff.000010.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000017.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_003_005.fits 3-diff.000010.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000018.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_003_006.fits 3-diff.000010.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000024.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_004_006.fits 3-diff.000010.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000015.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_003_003.fits 3-diff.000010.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000032.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_006_002.fits 3-diff.000010.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000023.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_004_005.fits 3-diff.000010.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000026.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_005_002.fits 3-diff.000010.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000029.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_005_005.fits 3-diff.000010.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000016.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_003_004.fits 3-diff.000010.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000019.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_004_001.fits 3-diff.000010.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000020.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_004_002.fits 3-diff.000010.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000027.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_005_003.fits 3-diff.000010.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000022.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_004_004.fits 3-diff.000010.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000012.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_002_006.fits 3-diff.000010.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000031.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_006_001.fits 3-diff.000010.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000011.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_002_005.fits 3-diff.000010.000011.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000010.000030.txt pposs2ukstu_ir_002_004.fits pposs2ukstu_ir_005_006.fits 3-diff.000010.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000012.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_002_006.fits 3-diff.000011.000012.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000019.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_004_001.fits 3-diff.000011.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000028.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_005_004.fits 3-diff.000011.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000035.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_006_005.fits 3-diff.000011.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000014.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_003_002.fits 3-diff.000011.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000033.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_006_003.fits 3-diff.000011.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000021.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_004_003.fits 3-diff.000011.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000036.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_006_006.fits 3-diff.000011.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000030.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_005_006.fits 3-diff.000011.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000022.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_004_004.fits 3-diff.000011.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000024.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_004_006.fits 3-diff.000011.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000029.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_005_005.fits 3-diff.000011.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000023.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_004_005.fits 3-diff.000011.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000017.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_003_005.fits 3-diff.000011.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000018.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_003_006.fits 3-diff.000011.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000032.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_006_002.fits 3-diff.000011.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000031.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_006_001.fits 3-diff.000011.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000016.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_003_004.fits 3-diff.000011.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000027.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_005_003.fits 3-diff.000011.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000020.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_004_002.fits 3-diff.000011.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000026.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_005_002.fits 3-diff.000011.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000015.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_003_003.fits 3-diff.000011.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000025.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_005_001.fits 3-diff.000011.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000034.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_006_004.fits 3-diff.000011.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000011.000013.txt pposs2ukstu_ir_002_005.fits pposs2ukstu_ir_003_001.fits 3-diff.000011.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000015.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_003_003.fits 3-diff.000012.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000024.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_004_006.fits 3-diff.000012.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000034.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_006_004.fits 3-diff.000012.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000030.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_005_006.fits 3-diff.000012.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000031.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_006_001.fits 3-diff.000012.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000028.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_005_004.fits 3-diff.000012.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000027.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_005_003.fits 3-diff.000012.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000032.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_006_002.fits 3-diff.000012.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000022.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_004_004.fits 3-diff.000012.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000035.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_006_005.fits 3-diff.000012.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000021.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_004_003.fits 3-diff.000012.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000017.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_003_005.fits 3-diff.000012.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000036.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_006_006.fits 3-diff.000012.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000014.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_003_002.fits 3-diff.000012.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000013.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_003_001.fits 3-diff.000012.000013.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000018.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_003_006.fits 3-diff.000012.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000026.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_005_002.fits 3-diff.000012.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000020.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_004_002.fits 3-diff.000012.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000033.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_006_003.fits 3-diff.000012.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000019.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_004_001.fits 3-diff.000012.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000016.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_003_004.fits 3-diff.000012.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000023.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_004_005.fits 3-diff.000012.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000025.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_005_001.fits 3-diff.000012.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000012.000029.txt pposs2ukstu_ir_002_006.fits pposs2ukstu_ir_005_005.fits 3-diff.000012.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000019.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_004_001.fits 3-diff.000013.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000028.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_005_004.fits 3-diff.000013.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000035.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_006_005.fits 3-diff.000013.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000034.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_006_004.fits 3-diff.000013.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000022.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_004_004.fits 3-diff.000013.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000030.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_005_006.fits 3-diff.000013.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000024.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_004_006.fits 3-diff.000013.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000029.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_005_005.fits 3-diff.000013.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000015.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_003_003.fits 3-diff.000013.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000021.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_004_003.fits 3-diff.000013.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000031.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_006_001.fits 3-diff.000013.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000018.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_003_006.fits 3-diff.000013.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000014.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_003_002.fits 3-diff.000013.000014.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000023.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_004_005.fits 3-diff.000013.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000032.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_006_002.fits 3-diff.000013.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000020.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_004_002.fits 3-diff.000013.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000033.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_006_003.fits 3-diff.000013.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000017.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_003_005.fits 3-diff.000013.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000027.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_005_003.fits 3-diff.000013.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000025.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_005_001.fits 3-diff.000013.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000016.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_003_004.fits 3-diff.000013.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000026.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_005_002.fits 3-diff.000013.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000013.000036.txt pposs2ukstu_ir_003_001.fits pposs2ukstu_ir_006_006.fits 3-diff.000013.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000016.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_003_004.fits 3-diff.000014.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000035.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_006_005.fits 3-diff.000014.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000022.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_004_004.fits 3-diff.000014.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000027.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_005_003.fits 3-diff.000014.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000024.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_004_006.fits 3-diff.000014.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000020.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_004_002.fits 3-diff.000014.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000029.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_005_005.fits 3-diff.000014.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000019.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_004_001.fits 3-diff.000014.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000031.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_006_001.fits 3-diff.000014.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000034.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_006_004.fits 3-diff.000014.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000036.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_006_006.fits 3-diff.000014.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000021.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_004_003.fits 3-diff.000014.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000032.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_006_002.fits 3-diff.000014.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000015.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_003_003.fits 3-diff.000014.000015.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000023.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_004_005.fits 3-diff.000014.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000026.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_005_002.fits 3-diff.000014.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000017.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_003_005.fits 3-diff.000014.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000025.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_005_001.fits 3-diff.000014.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000018.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_003_006.fits 3-diff.000014.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000033.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_006_003.fits 3-diff.000014.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000030.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_005_006.fits 3-diff.000014.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000014.000028.txt pposs2ukstu_ir_003_002.fits pposs2ukstu_ir_005_004.fits 3-diff.000014.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000022.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_004_004.fits 3-diff.000015.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000030.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_005_006.fits 3-diff.000015.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000024.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_004_006.fits 3-diff.000015.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000034.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_006_004.fits 3-diff.000015.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000029.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_005_005.fits 3-diff.000015.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000017.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_003_005.fits 3-diff.000015.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000027.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_005_003.fits 3-diff.000015.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000018.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_003_006.fits 3-diff.000015.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000025.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_005_001.fits 3-diff.000015.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000019.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_004_001.fits 3-diff.000015.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000023.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_004_005.fits 3-diff.000015.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000032.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_006_002.fits 3-diff.000015.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000020.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_004_002.fits 3-diff.000015.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000026.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_005_002.fits 3-diff.000015.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000031.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_006_001.fits 3-diff.000015.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000028.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_005_004.fits 3-diff.000015.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000021.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_004_003.fits 3-diff.000015.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000033.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_006_003.fits 3-diff.000015.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000016.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_003_004.fits 3-diff.000015.000016.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000035.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_006_005.fits 3-diff.000015.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000015.000036.txt pposs2ukstu_ir_003_003.fits pposs2ukstu_ir_006_006.fits 3-diff.000015.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000028.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_005_004.fits 3-diff.000016.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000026.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_005_002.fits 3-diff.000016.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000019.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_004_001.fits 3-diff.000016.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000029.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_005_005.fits 3-diff.000016.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000034.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_006_004.fits 3-diff.000016.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000036.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_006_006.fits 3-diff.000016.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000032.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_006_002.fits 3-diff.000016.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000017.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_003_005.fits 3-diff.000016.000017.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000033.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_006_003.fits 3-diff.000016.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000027.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_005_003.fits 3-diff.000016.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000035.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_006_005.fits 3-diff.000016.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000018.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_003_006.fits 3-diff.000016.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000025.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_005_001.fits 3-diff.000016.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000020.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_004_002.fits 3-diff.000016.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000021.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_004_003.fits 3-diff.000016.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000030.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_005_006.fits 3-diff.000016.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000023.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_004_005.fits 3-diff.000016.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000031.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_006_001.fits 3-diff.000016.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000022.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_004_004.fits 3-diff.000016.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000016.000024.txt pposs2ukstu_ir_003_004.fits pposs2ukstu_ir_004_006.fits 3-diff.000016.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000024.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_004_006.fits 3-diff.000017.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000027.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_005_003.fits 3-diff.000017.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000034.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_006_004.fits 3-diff.000017.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000026.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_005_002.fits 3-diff.000017.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000035.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_006_005.fits 3-diff.000017.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000025.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_005_001.fits 3-diff.000017.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000036.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_006_006.fits 3-diff.000017.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000029.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_005_005.fits 3-diff.000017.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000018.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_003_006.fits 3-diff.000017.000018.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000030.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_005_006.fits 3-diff.000017.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000032.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_006_002.fits 3-diff.000017.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000033.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_006_003.fits 3-diff.000017.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000031.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_006_001.fits 3-diff.000017.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000021.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_004_003.fits 3-diff.000017.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000023.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_004_005.fits 3-diff.000017.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000022.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_004_004.fits 3-diff.000017.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000020.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_004_002.fits 3-diff.000017.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000028.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_005_004.fits 3-diff.000017.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000017.000019.txt pposs2ukstu_ir_003_005.fits pposs2ukstu_ir_004_001.fits 3-diff.000017.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000020.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_004_002.fits 3-diff.000018.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000031.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_006_001.fits 3-diff.000018.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000022.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_004_004.fits 3-diff.000018.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000035.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_006_005.fits 3-diff.000018.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000034.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_006_004.fits 3-diff.000018.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000030.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_005_006.fits 3-diff.000018.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000032.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_006_002.fits 3-diff.000018.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000036.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_006_006.fits 3-diff.000018.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000024.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_004_006.fits 3-diff.000018.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000026.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_005_002.fits 3-diff.000018.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000019.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_004_001.fits 3-diff.000018.000019.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000027.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_005_003.fits 3-diff.000018.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000028.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_005_004.fits 3-diff.000018.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000023.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_004_005.fits 3-diff.000018.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000029.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_005_005.fits 3-diff.000018.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000033.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_006_003.fits 3-diff.000018.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000021.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_004_003.fits 3-diff.000018.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000018.000025.txt pposs2ukstu_ir_003_006.fits pposs2ukstu_ir_005_001.fits 3-diff.000018.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000022.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_004_004.fits 3-diff.000019.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000029.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_005_005.fits 3-diff.000019.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000025.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_005_001.fits 3-diff.000019.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000021.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_004_003.fits 3-diff.000019.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000031.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_006_001.fits 3-diff.000019.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000036.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_006_006.fits 3-diff.000019.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000032.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_006_002.fits 3-diff.000019.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000028.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_005_004.fits 3-diff.000019.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000033.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_006_003.fits 3-diff.000019.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000030.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_005_006.fits 3-diff.000019.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000026.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_005_002.fits 3-diff.000019.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000023.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_004_005.fits 3-diff.000019.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000034.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_006_004.fits 3-diff.000019.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000024.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_004_006.fits 3-diff.000019.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000027.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_005_003.fits 3-diff.000019.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000035.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_006_005.fits 3-diff.000019.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000019.000020.txt pposs2ukstu_ir_004_001.fits pposs2ukstu_ir_004_002.fits 3-diff.000019.000020.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000033.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_006_003.fits 3-diff.000020.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000026.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_005_002.fits 3-diff.000020.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000036.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_006_006.fits 3-diff.000020.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000023.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_004_005.fits 3-diff.000020.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000034.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_006_004.fits 3-diff.000020.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000021.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_004_003.fits 3-diff.000020.000021.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000025.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_005_001.fits 3-diff.000020.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000024.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_004_006.fits 3-diff.000020.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000029.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_005_005.fits 3-diff.000020.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000031.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_006_001.fits 3-diff.000020.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000027.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_005_003.fits 3-diff.000020.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000030.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_005_006.fits 3-diff.000020.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000035.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_006_005.fits 3-diff.000020.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000022.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_004_004.fits 3-diff.000020.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000028.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_005_004.fits 3-diff.000020.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000020.000032.txt pposs2ukstu_ir_004_002.fits pposs2ukstu_ir_006_002.fits 3-diff.000020.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000036.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_006_006.fits 3-diff.000021.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000035.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_006_005.fits 3-diff.000021.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000023.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_004_005.fits 3-diff.000021.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000033.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_006_003.fits 3-diff.000021.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000031.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_006_001.fits 3-diff.000021.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000029.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_005_005.fits 3-diff.000021.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000032.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_006_002.fits 3-diff.000021.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000022.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_004_004.fits 3-diff.000021.000022.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000028.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_005_004.fits 3-diff.000021.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000034.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_006_004.fits 3-diff.000021.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000025.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_005_001.fits 3-diff.000021.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000027.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_005_003.fits 3-diff.000021.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000024.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_004_006.fits 3-diff.000021.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000030.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_005_006.fits 3-diff.000021.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000021.000026.txt pposs2ukstu_ir_004_003.fits pposs2ukstu_ir_005_002.fits 3-diff.000021.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000035.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_006_005.fits 3-diff.000022.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000028.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_005_004.fits 3-diff.000022.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000026.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_005_002.fits 3-diff.000022.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000032.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_006_002.fits 3-diff.000022.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000030.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_005_006.fits 3-diff.000022.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000033.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_006_003.fits 3-diff.000022.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000036.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_006_006.fits 3-diff.000022.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000024.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_004_006.fits 3-diff.000022.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000034.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_006_004.fits 3-diff.000022.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000023.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_004_005.fits 3-diff.000022.000023.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000025.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_005_001.fits 3-diff.000022.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000029.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_005_005.fits 3-diff.000022.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000031.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_006_001.fits 3-diff.000022.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000022.000027.txt pposs2ukstu_ir_004_004.fits pposs2ukstu_ir_005_003.fits 3-diff.000022.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000031.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_006_001.fits 3-diff.000023.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000028.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_005_004.fits 3-diff.000023.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000026.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_005_002.fits 3-diff.000023.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000029.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_005_005.fits 3-diff.000023.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000035.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_006_005.fits 3-diff.000023.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000025.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_005_001.fits 3-diff.000023.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000033.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_006_003.fits 3-diff.000023.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000036.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_006_006.fits 3-diff.000023.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000032.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_006_002.fits 3-diff.000023.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000024.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_004_006.fits 3-diff.000023.000024.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000030.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_005_006.fits 3-diff.000023.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000027.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_005_003.fits 3-diff.000023.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000023.000034.txt pposs2ukstu_ir_004_005.fits pposs2ukstu_ir_006_004.fits 3-diff.000023.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000032.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_006_002.fits 3-diff.000024.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000029.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_005_005.fits 3-diff.000024.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000025.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_005_001.fits 3-diff.000024.000025.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000031.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_006_001.fits 3-diff.000024.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000035.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_006_005.fits 3-diff.000024.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000030.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_005_006.fits 3-diff.000024.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000036.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_006_006.fits 3-diff.000024.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000028.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_005_004.fits 3-diff.000024.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000033.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_006_003.fits 3-diff.000024.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000034.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_006_004.fits 3-diff.000024.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000026.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_005_002.fits 3-diff.000024.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000024.000027.txt pposs2ukstu_ir_004_006.fits pposs2ukstu_ir_005_003.fits 3-diff.000024.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000029.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_005_005.fits 3-diff.000025.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000035.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_006_005.fits 3-diff.000025.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000032.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_006_002.fits 3-diff.000025.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000033.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_006_003.fits 3-diff.000025.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000030.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_005_006.fits 3-diff.000025.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000031.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_006_001.fits 3-diff.000025.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000026.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_005_002.fits 3-diff.000025.000026.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000036.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_006_006.fits 3-diff.000025.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000034.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_006_004.fits 3-diff.000025.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000028.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_005_004.fits 3-diff.000025.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000025.000027.txt pposs2ukstu_ir_005_001.fits pposs2ukstu_ir_005_003.fits 3-diff.000025.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000034.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_006_004.fits 3-diff.000026.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000032.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_006_002.fits 3-diff.000026.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000036.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_006_006.fits 3-diff.000026.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000031.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_006_001.fits 3-diff.000026.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000028.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_005_004.fits 3-diff.000026.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000027.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_005_003.fits 3-diff.000026.000027.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000035.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_006_005.fits 3-diff.000026.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000029.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_005_005.fits 3-diff.000026.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000033.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_006_003.fits 3-diff.000026.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000026.000030.txt pposs2ukstu_ir_005_002.fits pposs2ukstu_ir_005_006.fits 3-diff.000026.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000034.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_006_004.fits 3-diff.000027.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000033.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_006_003.fits 3-diff.000027.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000031.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_006_001.fits 3-diff.000027.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000029.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_005_005.fits 3-diff.000027.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000035.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_006_005.fits 3-diff.000027.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000036.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_006_006.fits 3-diff.000027.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000028.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_005_004.fits 3-diff.000027.000028.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000030.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_005_006.fits 3-diff.000027.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000027.000032.txt pposs2ukstu_ir_005_003.fits pposs2ukstu_ir_006_002.fits 3-diff.000027.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000033.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_006_003.fits 3-diff.000028.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000036.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_006_006.fits 3-diff.000028.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000032.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_006_002.fits 3-diff.000028.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000034.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_006_004.fits 3-diff.000028.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000031.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_006_001.fits 3-diff.000028.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000030.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_005_006.fits 3-diff.000028.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000035.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_006_005.fits 3-diff.000028.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000028.000029.txt pposs2ukstu_ir_005_004.fits pposs2ukstu_ir_005_005.fits 3-diff.000028.000029.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000035.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_006_005.fits 3-diff.000029.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000030.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_005_006.fits 3-diff.000029.000030.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000033.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_006_003.fits 3-diff.000029.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000032.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_006_002.fits 3-diff.000029.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000031.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_006_001.fits 3-diff.000029.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000034.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_006_004.fits 3-diff.000029.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000029.000036.txt pposs2ukstu_ir_005_005.fits pposs2ukstu_ir_006_006.fits 3-diff.000029.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000030.000032.txt pposs2ukstu_ir_005_006.fits pposs2ukstu_ir_006_002.fits 3-diff.000030.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000030.000036.txt pposs2ukstu_ir_005_006.fits pposs2ukstu_ir_006_006.fits 3-diff.000030.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000030.000035.txt pposs2ukstu_ir_005_006.fits pposs2ukstu_ir_006_005.fits 3-diff.000030.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000030.000031.txt pposs2ukstu_ir_005_006.fits pposs2ukstu_ir_006_001.fits 3-diff.000030.000031.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000030.000034.txt pposs2ukstu_ir_005_006.fits pposs2ukstu_ir_006_004.fits 3-diff.000030.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000030.000033.txt pposs2ukstu_ir_005_006.fits pposs2ukstu_ir_006_003.fits 3-diff.000030.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000031.000035.txt pposs2ukstu_ir_006_001.fits pposs2ukstu_ir_006_005.fits 3-diff.000031.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000031.000036.txt pposs2ukstu_ir_006_001.fits pposs2ukstu_ir_006_006.fits 3-diff.000031.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000031.000033.txt pposs2ukstu_ir_006_001.fits pposs2ukstu_ir_006_003.fits 3-diff.000031.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000031.000034.txt pposs2ukstu_ir_006_001.fits pposs2ukstu_ir_006_004.fits 3-diff.000031.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000031.000032.txt pposs2ukstu_ir_006_001.fits pposs2ukstu_ir_006_002.fits 3-diff.000031.000032.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000032.000033.txt pposs2ukstu_ir_006_002.fits pposs2ukstu_ir_006_003.fits 3-diff.000032.000033.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000032.000036.txt pposs2ukstu_ir_006_002.fits pposs2ukstu_ir_006_006.fits 3-diff.000032.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000032.000034.txt pposs2ukstu_ir_006_002.fits pposs2ukstu_ir_006_004.fits 3-diff.000032.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000032.000035.txt pposs2ukstu_ir_006_002.fits pposs2ukstu_ir_006_005.fits 3-diff.000032.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000033.000036.txt pposs2ukstu_ir_006_003.fits pposs2ukstu_ir_006_006.fits 3-diff.000033.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000033.000035.txt pposs2ukstu_ir_006_003.fits pposs2ukstu_ir_006_005.fits 3-diff.000033.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000033.000034.txt pposs2ukstu_ir_006_003.fits pposs2ukstu_ir_006_004.fits 3-diff.000033.000034.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000034.000035.txt pposs2ukstu_ir_006_004.fits pposs2ukstu_ir_006_005.fits 3-diff.000034.000035.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000034.000036.txt pposs2ukstu_ir_006_004.fits pposs2ukstu_ir_006_006.fits 3-diff.000034.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mDiffFit -d -s 3-fit.000035.000036.txt pposs2ukstu_ir_006_005.fits pposs2ukstu_ir_006_006.fits 3-diff.000035.000036.fits region-oversized.hdr 
$MONTAGE_PATH/bin/mConcatFit 1-stat.tbl 1-fits.tbl . 
$MONTAGE_PATH/bin/mConcatFit 2-stat.tbl 2-fits.tbl . 
$MONTAGE_PATH/bin/mConcatFit 3-stat.tbl 3-fits.tbl . 
$MONTAGE_PATH/bin/mBgModel -i 100000 1-images.tbl 1-fits.tbl 1-corrections.tbl 
$MONTAGE_PATH/bin/mBgModel -i 100000 2-images.tbl 2-fits.tbl 2-corrections.tbl 
$MONTAGE_PATH/bin/mBgModel -i 100000 3-images.tbl 3-fits.tbl 3-corrections.tbl 
$MONTAGE_PATH/bin/mImgtbl . -t 1-corrected.tbl 1-updated-corrected.tbl 
$MONTAGE_PATH/bin/mImgtbl . -t 2-corrected.tbl 2-updated-corrected.tbl 
$MONTAGE_PATH/bin/mImgtbl . -t 3-corrected.tbl 3-updated-corrected.tbl 
$MONTAGE_PATH/bin/mAdd -e 1-updated-corrected.tbl region.hdr 1-mosaic.fits 
$MONTAGE_PATH/bin/mAdd -e 2-updated-corrected.tbl region.hdr 2-mosaic.fits 
$MONTAGE_PATH/bin/mAdd -e 3-updated-corrected.tbl region.hdr 3-mosaic.fits 
$MONTAGE_PATH/bin/mViewer -ct 1 -gray 1-mosaic.fits -1s max gaussian -png 1-mosaic.png 
$MONTAGE_PATH/bin/mViewer -red 3-mosaic.fits -0.5s max gaussian-log -green 2-mosaic.fits -0.5s max gaussian-log -blue 1-mosaic.fits -0.5s max gaussian-log -png mosaic-color.png 
$MONTAGE_PATH/bin/mViewer -ct 1 -gray 2-mosaic.fits -1s max gaussian -png 2-mosaic.png 
$MONTAGE_PATH/bin/mViewer -ct 1 -gray 3-mosaic.fits -1s max gaussian -png 3-mosaic.png 
